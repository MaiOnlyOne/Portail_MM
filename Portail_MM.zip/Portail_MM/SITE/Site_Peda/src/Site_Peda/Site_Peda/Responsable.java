/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Responsable</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Responsable#getNom <em>Nom</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Responsable#getIdentifiant <em>Identifiant</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Responsable#getAdresse <em>Adresse</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Responsable#getTelephone <em>Telephone</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Responsable#getDepartement <em>Departement</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueNom'"
 * @generated
 */
public interface Responsable extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable_Nom()
	 * @model required="true"
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Responsable#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Identifiant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifiant</em>' attribute.
	 * @see #setIdentifiant(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable_Identifiant()
	 * @model
	 * @generated
	 */
	String getIdentifiant();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Responsable#getIdentifiant <em>Identifiant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Identifiant</em>' attribute.
	 * @see #getIdentifiant()
	 * @generated
	 */
	void setIdentifiant(String value);

	/**
	 * Returns the value of the '<em><b>Adresse</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Adresse</em>' attribute.
	 * @see #setAdresse(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable_Adresse()
	 * @model
	 * @generated
	 */
	String getAdresse();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Responsable#getAdresse <em>Adresse</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Adresse</em>' attribute.
	 * @see #getAdresse()
	 * @generated
	 */
	void setAdresse(String value);

	/**
	 * Returns the value of the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Telephone</em>' attribute.
	 * @see #setTelephone(Integer)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable_Telephone()
	 * @model
	 * @generated
	 */
	Integer getTelephone();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Responsable#getTelephone <em>Telephone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Telephone</em>' attribute.
	 * @see #getTelephone()
	 * @generated
	 */
	void setTelephone(Integer value);

	/**
	 * Returns the value of the '<em><b>Departement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Departement</em>' reference.
	 * @see #setDepartement(Departement)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getResponsable_Departement()
	 * @model
	 * @generated
	 */
	Departement getDepartement();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Responsable#getDepartement <em>Departement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Departement</em>' reference.
	 * @see #getDepartement()
	 * @generated
	 */
	void setDepartement(Departement value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t Responsable.allInstances()-&gt;forAll(r1,r2|r1&lt;&gt;r2 implies r1.nom &lt;&gt; r2.nom)'"
	 * @generated
	 */
	boolean UniqueNom(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Responsable

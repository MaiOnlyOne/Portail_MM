/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Departement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getNom <em>Nom</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getSiteWeb <em>Site Web</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getTelephone <em>Telephone</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getEmail <em>Email</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getA_responsable <em>Aresponsable</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Departement#getFormation <em>Formation</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueNom'"
 * @generated
 */
public interface Departement extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_Nom()
	 * @model required="true"
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Departement#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Site Web</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Site Web</em>' attribute.
	 * @see #setSiteWeb(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_SiteWeb()
	 * @model
	 * @generated
	 */
	String getSiteWeb();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Departement#getSiteWeb <em>Site Web</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Site Web</em>' attribute.
	 * @see #getSiteWeb()
	 * @generated
	 */
	void setSiteWeb(String value);

	/**
	 * Returns the value of the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Telephone</em>' attribute.
	 * @see #setTelephone(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_Telephone()
	 * @model
	 * @generated
	 */
	String getTelephone();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Departement#getTelephone <em>Telephone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Telephone</em>' attribute.
	 * @see #getTelephone()
	 * @generated
	 */
	void setTelephone(String value);

	/**
	 * Returns the value of the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Email</em>' attribute.
	 * @see #setEmail(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_Email()
	 * @model
	 * @generated
	 */
	String getEmail();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Departement#getEmail <em>Email</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Email</em>' attribute.
	 * @see #getEmail()
	 * @generated
	 */
	void setEmail(String value);

	/**
	 * Returns the value of the '<em><b>Aresponsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aresponsable</em>' containment reference.
	 * @see #setA_responsable(Responsable)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_A_responsable()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Responsable getA_responsable();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Departement#getA_responsable <em>Aresponsable</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Aresponsable</em>' containment reference.
	 * @see #getA_responsable()
	 * @generated
	 */
	void setA_responsable(Responsable value);

	/**
	 * Returns the value of the '<em><b>Formation</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Formation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Formation</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getDepartement_Formation()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Formation> getFormation();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t Departement.allInstances()-&gt;forAll(d1,d2|d1&lt;&gt;d2 implies d1.nom &lt;&gt; d2.nom)'"
	 * @generated
	 */
	boolean UniqueNom(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Departement

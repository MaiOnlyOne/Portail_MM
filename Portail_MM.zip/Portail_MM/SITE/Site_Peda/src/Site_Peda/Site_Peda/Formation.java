/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Formation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Formation#getNom <em>Nom</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Formation#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Formation#getNiveau <em>Niveau</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getFormation()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueNom'"
 * @generated
 */
public interface Formation extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getFormation_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Formation#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getFormation_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Formation#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Niveau</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Niveau}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Niveau</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getFormation_Niveau()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Niveau> getNiveau();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t Formation.allInstances()-&gt;forAll(f1,f2|f1&lt;&gt;f2 implies f1.nom &lt;&gt; f2.nom)'"
	 * @generated
	 */
	boolean UniqueNom(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Formation

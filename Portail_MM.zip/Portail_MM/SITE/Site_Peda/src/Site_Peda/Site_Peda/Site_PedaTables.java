/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /Site_Peda/model/Site_Pedag.ecore
 * using:
 *   /Site_Peda/model/Site_Peda.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package Site_Peda.Site_Peda;

// import Site_Peda.Site_Peda.Site_PedaPackage;
// import Site_Peda.Site_Peda.Site_PedaTables;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;

/**
 * Site_PedaTables provides the dispatch tables for the Site_Peda for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class Site_PedaTables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(Site_PedaPackage.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ RootPackageId PACKid_$metamodel$ = IdManager.getRootPackageId("$metamodel$");
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_example_org_s_site_Peda = IdManager.getNsURIPackageId("http://www.example.org/site_Peda", null, Site_PedaPackage.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_Class = Site_PedaTables.PACKid_$metamodel$.getClassId("Class", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Departement = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Departement", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Formation = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Formation", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Niveau = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Niveau", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Responsable = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Responsable", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Ressource = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Ressource", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_SalleCours = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("SalleCours", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Semainier = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Semainier", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Semestre = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Semestre", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Specialite = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("Specialite", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_UE = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getClassId("UE", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = Site_PedaTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EIntegerObject = Site_PedaTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EIntegerObject", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_Jour = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getEnumerationId("Jour");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_TypeRess = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getEnumerationId("TypeRess");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_TypeSE = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getEnumerationId("TypeSE");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_TypeUE = Site_PedaTables.PACKid_http_c_s_s_www_example_org_s_site_Peda.getEnumerationId("TypeUE");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_2 = ValueUtil.integerValueOf("2");
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Responsable = TypeId.BAG.getSpecializedId(Site_PedaTables.CLSSid_Responsable, false, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Formation = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Formation, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Niveau = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Niveau, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Ressource = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Ressource, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_SalleCours = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_SalleCours, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Semainier = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Semainier, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Semestre = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Semestre, true, ValueUtil.integerValueOf(2), ValueUtil.integerValueOf(2));
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Specialite = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_Specialite, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_UE = TypeId.ORDERED_SET.getSpecializedId(Site_PedaTables.CLSSid_UE, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Departement = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_Departement, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Formation = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_Formation, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Niveau = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_Niveau, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Responsable = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_Responsable, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_SalleCours = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_SalleCours, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Specialite = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_Specialite, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_UE = TypeId.SET.getSpecializedId(Site_PedaTables.CLSSid_UE, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			Site_PedaTables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _Departement = new EcoreExecutorType(Site_PedaPackage.Literals.DEPARTEMENT, PACKAGE, 0);
		public static final EcoreExecutorType _Formation = new EcoreExecutorType(Site_PedaPackage.Literals.FORMATION, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _Jour = new EcoreExecutorEnumeration(Site_PedaPackage.Literals.JOUR, PACKAGE, 0);
		public static final EcoreExecutorType _Niveau = new EcoreExecutorType(Site_PedaPackage.Literals.NIVEAU, PACKAGE, 0);
		public static final EcoreExecutorType _Responsable = new EcoreExecutorType(Site_PedaPackage.Literals.RESPONSABLE, PACKAGE, 0);
		public static final EcoreExecutorType _Ressource = new EcoreExecutorType(Site_PedaPackage.Literals.RESSOURCE, PACKAGE, 0);
		public static final EcoreExecutorType _SalleCours = new EcoreExecutorType(Site_PedaPackage.Literals.SALLE_COURS, PACKAGE, 0);
		public static final EcoreExecutorType _Semainier = new EcoreExecutorType(Site_PedaPackage.Literals.SEMAINIER, PACKAGE, 0);
		public static final EcoreExecutorType _Semestre = new EcoreExecutorType(Site_PedaPackage.Literals.SEMESTRE, PACKAGE, 0);
		public static final EcoreExecutorType _Specialite = new EcoreExecutorType(Site_PedaPackage.Literals.SPECIALITE, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _TypeRess = new EcoreExecutorEnumeration(Site_PedaPackage.Literals.TYPE_RESS, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _TypeSE = new EcoreExecutorEnumeration(Site_PedaPackage.Literals.TYPE_SE, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _TypeUE = new EcoreExecutorEnumeration(Site_PedaPackage.Literals.TYPE_UE, PACKAGE, 0);
		public static final EcoreExecutorType _UE = new EcoreExecutorType(Site_PedaPackage.Literals.UE, PACKAGE, 0);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_Departement,
			_Formation,
			_Jour,
			_Niveau,
			_Responsable,
			_Ressource,
			_SalleCours,
			_Semainier,
			_Semestre,
			_Specialite,
			_TypeRess,
			_TypeSE,
			_TypeUE,
			_UE
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _Departement__Departement = new ExecutorFragment(Types._Departement, Site_PedaTables.Types._Departement);
		private static final ExecutorFragment _Departement__OclAny = new ExecutorFragment(Types._Departement, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Departement__OclElement = new ExecutorFragment(Types._Departement, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Formation__Formation = new ExecutorFragment(Types._Formation, Site_PedaTables.Types._Formation);
		private static final ExecutorFragment _Formation__OclAny = new ExecutorFragment(Types._Formation, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Formation__OclElement = new ExecutorFragment(Types._Formation, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Jour__Jour = new ExecutorFragment(Types._Jour, Site_PedaTables.Types._Jour);
		private static final ExecutorFragment _Jour__OclAny = new ExecutorFragment(Types._Jour, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Jour__OclElement = new ExecutorFragment(Types._Jour, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Jour__OclEnumeration = new ExecutorFragment(Types._Jour, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _Jour__OclType = new ExecutorFragment(Types._Jour, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Niveau__Niveau = new ExecutorFragment(Types._Niveau, Site_PedaTables.Types._Niveau);
		private static final ExecutorFragment _Niveau__OclAny = new ExecutorFragment(Types._Niveau, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Niveau__OclElement = new ExecutorFragment(Types._Niveau, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Responsable__OclAny = new ExecutorFragment(Types._Responsable, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Responsable__OclElement = new ExecutorFragment(Types._Responsable, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Responsable__Responsable = new ExecutorFragment(Types._Responsable, Site_PedaTables.Types._Responsable);

		private static final ExecutorFragment _Ressource__OclAny = new ExecutorFragment(Types._Ressource, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Ressource__OclElement = new ExecutorFragment(Types._Ressource, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Ressource__Ressource = new ExecutorFragment(Types._Ressource, Site_PedaTables.Types._Ressource);

		private static final ExecutorFragment _SalleCours__OclAny = new ExecutorFragment(Types._SalleCours, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _SalleCours__OclElement = new ExecutorFragment(Types._SalleCours, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _SalleCours__SalleCours = new ExecutorFragment(Types._SalleCours, Site_PedaTables.Types._SalleCours);

		private static final ExecutorFragment _Semainier__OclAny = new ExecutorFragment(Types._Semainier, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Semainier__OclElement = new ExecutorFragment(Types._Semainier, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Semainier__Semainier = new ExecutorFragment(Types._Semainier, Site_PedaTables.Types._Semainier);

		private static final ExecutorFragment _Semestre__OclAny = new ExecutorFragment(Types._Semestre, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Semestre__OclElement = new ExecutorFragment(Types._Semestre, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Semestre__Semestre = new ExecutorFragment(Types._Semestre, Site_PedaTables.Types._Semestre);

		private static final ExecutorFragment _Specialite__OclAny = new ExecutorFragment(Types._Specialite, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Specialite__OclElement = new ExecutorFragment(Types._Specialite, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Specialite__Specialite = new ExecutorFragment(Types._Specialite, Site_PedaTables.Types._Specialite);

		private static final ExecutorFragment _TypeRess__OclAny = new ExecutorFragment(Types._TypeRess, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _TypeRess__OclElement = new ExecutorFragment(Types._TypeRess, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _TypeRess__OclEnumeration = new ExecutorFragment(Types._TypeRess, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _TypeRess__OclType = new ExecutorFragment(Types._TypeRess, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _TypeRess__TypeRess = new ExecutorFragment(Types._TypeRess, Site_PedaTables.Types._TypeRess);

		private static final ExecutorFragment _TypeSE__OclAny = new ExecutorFragment(Types._TypeSE, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _TypeSE__OclElement = new ExecutorFragment(Types._TypeSE, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _TypeSE__OclEnumeration = new ExecutorFragment(Types._TypeSE, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _TypeSE__OclType = new ExecutorFragment(Types._TypeSE, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _TypeSE__TypeSE = new ExecutorFragment(Types._TypeSE, Site_PedaTables.Types._TypeSE);

		private static final ExecutorFragment _TypeUE__OclAny = new ExecutorFragment(Types._TypeUE, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _TypeUE__OclElement = new ExecutorFragment(Types._TypeUE, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _TypeUE__OclEnumeration = new ExecutorFragment(Types._TypeUE, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _TypeUE__OclType = new ExecutorFragment(Types._TypeUE, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _TypeUE__TypeUE = new ExecutorFragment(Types._TypeUE, Site_PedaTables.Types._TypeUE);

		private static final ExecutorFragment _UE__OclAny = new ExecutorFragment(Types._UE, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _UE__OclElement = new ExecutorFragment(Types._UE, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _UE__UE = new ExecutorFragment(Types._UE, Site_PedaTables.Types._UE);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _Departement__a_responsable = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__ARESPONSABLE, Types._Departement, 0);
		public static final ExecutorProperty _Departement__email = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__EMAIL, Types._Departement, 1);
		public static final ExecutorProperty _Departement__formation = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__FORMATION, Types._Departement, 2);
		public static final ExecutorProperty _Departement__nom = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__NOM, Types._Departement, 3);
		public static final ExecutorProperty _Departement__siteWeb = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__SITE_WEB, Types._Departement, 4);
		public static final ExecutorProperty _Departement__telephone = new EcoreExecutorProperty(Site_PedaPackage.Literals.DEPARTEMENT__TELEPHONE, Types._Departement, 5);
		public static final ExecutorProperty _Departement__Responsable__departement = new ExecutorPropertyWithImplementation("Responsable", Types._Departement, 6, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.RESPONSABLE__DEPARTEMENT));

		public static final ExecutorProperty _Formation__description = new EcoreExecutorProperty(Site_PedaPackage.Literals.FORMATION__DESCRIPTION, Types._Formation, 0);
		public static final ExecutorProperty _Formation__niveau = new EcoreExecutorProperty(Site_PedaPackage.Literals.FORMATION__NIVEAU, Types._Formation, 1);
		public static final ExecutorProperty _Formation__nom = new EcoreExecutorProperty(Site_PedaPackage.Literals.FORMATION__NOM, Types._Formation, 2);
		public static final ExecutorProperty _Formation__Departement__formation = new ExecutorPropertyWithImplementation("Departement", Types._Formation, 3, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.DEPARTEMENT__FORMATION));

		public static final ExecutorProperty _Niveau__code = new EcoreExecutorProperty(Site_PedaPackage.Literals.NIVEAU__CODE, Types._Niveau, 0);
		public static final ExecutorProperty _Niveau__description = new EcoreExecutorProperty(Site_PedaPackage.Literals.NIVEAU__DESCRIPTION, Types._Niveau, 1);
		public static final ExecutorProperty _Niveau__responsable = new EcoreExecutorProperty(Site_PedaPackage.Literals.NIVEAU__RESPONSABLE, Types._Niveau, 2);
		public static final ExecutorProperty _Niveau__semestre = new EcoreExecutorProperty(Site_PedaPackage.Literals.NIVEAU__SEMESTRE, Types._Niveau, 3);
		public static final ExecutorProperty _Niveau__specialite = new EcoreExecutorProperty(Site_PedaPackage.Literals.NIVEAU__SPECIALITE, Types._Niveau, 4);
		public static final ExecutorProperty _Niveau__Formation__niveau = new ExecutorPropertyWithImplementation("Formation", Types._Niveau, 5, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.FORMATION__NIVEAU));

		public static final ExecutorProperty _Responsable__adresse = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESPONSABLE__ADRESSE, Types._Responsable, 0);
		public static final ExecutorProperty _Responsable__departement = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESPONSABLE__DEPARTEMENT, Types._Responsable, 1);
		public static final ExecutorProperty _Responsable__identifiant = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESPONSABLE__IDENTIFIANT, Types._Responsable, 2);
		public static final ExecutorProperty _Responsable__nom = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESPONSABLE__NOM, Types._Responsable, 3);
		public static final ExecutorProperty _Responsable__telephone = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESPONSABLE__TELEPHONE, Types._Responsable, 4);
		public static final ExecutorProperty _Responsable__Departement__a_responsable = new ExecutorPropertyWithImplementation("Departement", Types._Responsable, 5, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.DEPARTEMENT__ARESPONSABLE));
		public static final ExecutorProperty _Responsable__Niveau__responsable = new ExecutorPropertyWithImplementation("Niveau", Types._Responsable, 6, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.NIVEAU__RESPONSABLE));
		public static final ExecutorProperty _Responsable__UE__possede_responsable = new ExecutorPropertyWithImplementation("UE", Types._Responsable, 7, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.UE__POSSEDE_RESPONSABLE));

		public static final ExecutorProperty _Ressource__nom = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESSOURCE__NOM, Types._Ressource, 0);
		public static final ExecutorProperty _Ressource__type = new EcoreExecutorProperty(Site_PedaPackage.Literals.RESSOURCE__TYPE, Types._Ressource, 1);
		public static final ExecutorProperty _Ressource__UE__ressource = new ExecutorPropertyWithImplementation("UE", Types._Ressource, 2, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.UE__RESSOURCE));

		public static final ExecutorProperty _SalleCours__code = new EcoreExecutorProperty(Site_PedaPackage.Literals.SALLE_COURS__CODE, Types._SalleCours, 0);
		public static final ExecutorProperty _SalleCours__estOccupe = new EcoreExecutorProperty(Site_PedaPackage.Literals.SALLE_COURS__EST_OCCUPE, Types._SalleCours, 1);
		public static final ExecutorProperty _SalleCours__nbrePlace = new EcoreExecutorProperty(Site_PedaPackage.Literals.SALLE_COURS__NBRE_PLACE, Types._SalleCours, 2);
		public static final ExecutorProperty _SalleCours__UE__sallecours = new ExecutorPropertyWithImplementation("UE", Types._SalleCours, 3, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.UE__SALLECOURS));

		public static final ExecutorProperty _Semainier__heureDebut = new EcoreExecutorProperty(Site_PedaPackage.Literals.SEMAINIER__HEURE_DEBUT, Types._Semainier, 0);
		public static final ExecutorProperty _Semainier__heureFin = new EcoreExecutorProperty(Site_PedaPackage.Literals.SEMAINIER__HEURE_FIN, Types._Semainier, 1);
		public static final ExecutorProperty _Semainier__jour = new EcoreExecutorProperty(Site_PedaPackage.Literals.SEMAINIER__JOUR, Types._Semainier, 2);
		public static final ExecutorProperty _Semainier__UE__semainier = new ExecutorPropertyWithImplementation("UE", Types._Semainier, 3, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.UE__SEMAINIER));

		public static final ExecutorProperty _Semestre__code = new EcoreExecutorProperty(Site_PedaPackage.Literals.SEMESTRE__CODE, Types._Semestre, 0);
		public static final ExecutorProperty _Semestre__ue = new EcoreExecutorProperty(Site_PedaPackage.Literals.SEMESTRE__UE, Types._Semestre, 1);
		public static final ExecutorProperty _Semestre__Niveau__semestre = new ExecutorPropertyWithImplementation("Niveau", Types._Semestre, 2, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.NIVEAU__SEMESTRE));
		public static final ExecutorProperty _Semestre__Specialite__semestre = new ExecutorPropertyWithImplementation("Specialite", Types._Semestre, 3, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.SPECIALITE__SEMESTRE));

		public static final ExecutorProperty _Specialite__description = new EcoreExecutorProperty(Site_PedaPackage.Literals.SPECIALITE__DESCRIPTION, Types._Specialite, 0);
		public static final ExecutorProperty _Specialite__nom = new EcoreExecutorProperty(Site_PedaPackage.Literals.SPECIALITE__NOM, Types._Specialite, 1);
		public static final ExecutorProperty _Specialite__semestre = new EcoreExecutorProperty(Site_PedaPackage.Literals.SPECIALITE__SEMESTRE, Types._Specialite, 2);
		public static final ExecutorProperty _Specialite__Niveau__specialite = new ExecutorPropertyWithImplementation("Niveau", Types._Specialite, 3, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.NIVEAU__SPECIALITE));

		public static final ExecutorProperty _UE__code = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__CODE, Types._UE, 0);
		public static final ExecutorProperty _UE__credit = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__CREDIT, Types._UE, 1);
		public static final ExecutorProperty _UE__description = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__DESCRIPTION, Types._UE, 2);
		public static final ExecutorProperty _UE__nbreEtudiant = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__NBRE_ETUDIANT, Types._UE, 3);
		public static final ExecutorProperty _UE__possede_responsable = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__POSSEDE_RESPONSABLE, Types._UE, 4);
		public static final ExecutorProperty _UE__ressource = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__RESSOURCE, Types._UE, 5);
		public static final ExecutorProperty _UE__sallecours = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__SALLECOURS, Types._UE, 6);
		public static final ExecutorProperty _UE__semainier = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__SEMAINIER, Types._UE, 7);
		public static final ExecutorProperty _UE__typeUe = new EcoreExecutorProperty(Site_PedaPackage.Literals.UE__TYPE_UE, Types._UE, 8);
		public static final ExecutorProperty _UE__Semestre__ue = new ExecutorPropertyWithImplementation("Semestre", Types._UE, 9, new EcoreLibraryOppositeProperty(Site_PedaPackage.Literals.SEMESTRE__UE));
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _Departement =
			{
				Fragments._Departement__OclAny /* 0 */,
				Fragments._Departement__OclElement /* 1 */,
				Fragments._Departement__Departement /* 2 */
			};
		private static final int /*@NonNull*/ [] __Departement = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Formation =
			{
				Fragments._Formation__OclAny /* 0 */,
				Fragments._Formation__OclElement /* 1 */,
				Fragments._Formation__Formation /* 2 */
			};
		private static final int /*@NonNull*/ [] __Formation = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Jour =
			{
				Fragments._Jour__OclAny /* 0 */,
				Fragments._Jour__OclElement /* 1 */,
				Fragments._Jour__OclType /* 2 */,
				Fragments._Jour__OclEnumeration /* 3 */,
				Fragments._Jour__Jour /* 4 */
			};
		private static final int /*@NonNull*/ [] __Jour = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Niveau =
			{
				Fragments._Niveau__OclAny /* 0 */,
				Fragments._Niveau__OclElement /* 1 */,
				Fragments._Niveau__Niveau /* 2 */
			};
		private static final int /*@NonNull*/ [] __Niveau = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Responsable =
			{
				Fragments._Responsable__OclAny /* 0 */,
				Fragments._Responsable__OclElement /* 1 */,
				Fragments._Responsable__Responsable /* 2 */
			};
		private static final int /*@NonNull*/ [] __Responsable = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Ressource =
			{
				Fragments._Ressource__OclAny /* 0 */,
				Fragments._Ressource__OclElement /* 1 */,
				Fragments._Ressource__Ressource /* 2 */
			};
		private static final int /*@NonNull*/ [] __Ressource = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _SalleCours =
			{
				Fragments._SalleCours__OclAny /* 0 */,
				Fragments._SalleCours__OclElement /* 1 */,
				Fragments._SalleCours__SalleCours /* 2 */
			};
		private static final int /*@NonNull*/ [] __SalleCours = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Semainier =
			{
				Fragments._Semainier__OclAny /* 0 */,
				Fragments._Semainier__OclElement /* 1 */,
				Fragments._Semainier__Semainier /* 2 */
			};
		private static final int /*@NonNull*/ [] __Semainier = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Semestre =
			{
				Fragments._Semestre__OclAny /* 0 */,
				Fragments._Semestre__OclElement /* 1 */,
				Fragments._Semestre__Semestre /* 2 */
			};
		private static final int /*@NonNull*/ [] __Semestre = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Specialite =
			{
				Fragments._Specialite__OclAny /* 0 */,
				Fragments._Specialite__OclElement /* 1 */,
				Fragments._Specialite__Specialite /* 2 */
			};
		private static final int /*@NonNull*/ [] __Specialite = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _TypeRess =
			{
				Fragments._TypeRess__OclAny /* 0 */,
				Fragments._TypeRess__OclElement /* 1 */,
				Fragments._TypeRess__OclType /* 2 */,
				Fragments._TypeRess__OclEnumeration /* 3 */,
				Fragments._TypeRess__TypeRess /* 4 */
			};
		private static final int /*@NonNull*/ [] __TypeRess = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _TypeSE =
			{
				Fragments._TypeSE__OclAny /* 0 */,
				Fragments._TypeSE__OclElement /* 1 */,
				Fragments._TypeSE__OclType /* 2 */,
				Fragments._TypeSE__OclEnumeration /* 3 */,
				Fragments._TypeSE__TypeSE /* 4 */
			};
		private static final int /*@NonNull*/ [] __TypeSE = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _TypeUE =
			{
				Fragments._TypeUE__OclAny /* 0 */,
				Fragments._TypeUE__OclElement /* 1 */,
				Fragments._TypeUE__OclType /* 2 */,
				Fragments._TypeUE__OclEnumeration /* 3 */,
				Fragments._TypeUE__TypeUE /* 4 */
			};
		private static final int /*@NonNull*/ [] __TypeUE = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _UE =
			{
				Fragments._UE__OclAny /* 0 */,
				Fragments._UE__OclElement /* 1 */,
				Fragments._UE__UE /* 2 */
			};
		private static final int /*@NonNull*/ [] __UE = { 1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._Departement.initFragments(_Departement, __Departement);
			Types._Formation.initFragments(_Formation, __Formation);
			Types._Jour.initFragments(_Jour, __Jour);
			Types._Niveau.initFragments(_Niveau, __Niveau);
			Types._Responsable.initFragments(_Responsable, __Responsable);
			Types._Ressource.initFragments(_Ressource, __Ressource);
			Types._SalleCours.initFragments(_SalleCours, __SalleCours);
			Types._Semainier.initFragments(_Semainier, __Semainier);
			Types._Semestre.initFragments(_Semestre, __Semestre);
			Types._Specialite.initFragments(_Specialite, __Specialite);
			Types._TypeRess.initFragments(_TypeRess, __TypeRess);
			Types._TypeSE.initFragments(_TypeSE, __TypeSE);
			Types._TypeUE.initFragments(_TypeUE, __TypeUE);
			Types._UE.initFragments(_UE, __UE);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _Departement__Departement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Departement__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Departement__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Formation__Formation = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Formation__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Formation__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Jour__Jour = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Jour__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Jour__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Jour__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Jour__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Niveau__Niveau = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Niveau__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Niveau__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Responsable__Responsable = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Responsable__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Responsable__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Ressource__Ressource = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Ressource__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Ressource__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _SalleCours__SalleCours = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SalleCours__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _SalleCours__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Semainier__Semainier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Semainier__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Semainier__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Semestre__Semestre = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Semestre__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Semestre__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Specialite__Specialite = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Specialite__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Specialite__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _TypeRess__TypeRess = {};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeRess__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeRess__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeRess__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeRess__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _TypeSE__TypeSE = {};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeSE__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeSE__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeSE__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeSE__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _TypeUE__TypeUE = {};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeUE__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeUE__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeUE__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TypeUE__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _UE__UE = {};
		private static final ExecutorOperation /*@NonNull*/ [] _UE__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _UE__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Departement__Departement.initOperations(_Departement__Departement);
			Fragments._Departement__OclAny.initOperations(_Departement__OclAny);
			Fragments._Departement__OclElement.initOperations(_Departement__OclElement);

			Fragments._Formation__Formation.initOperations(_Formation__Formation);
			Fragments._Formation__OclAny.initOperations(_Formation__OclAny);
			Fragments._Formation__OclElement.initOperations(_Formation__OclElement);

			Fragments._Jour__Jour.initOperations(_Jour__Jour);
			Fragments._Jour__OclAny.initOperations(_Jour__OclAny);
			Fragments._Jour__OclElement.initOperations(_Jour__OclElement);
			Fragments._Jour__OclEnumeration.initOperations(_Jour__OclEnumeration);
			Fragments._Jour__OclType.initOperations(_Jour__OclType);

			Fragments._Niveau__Niveau.initOperations(_Niveau__Niveau);
			Fragments._Niveau__OclAny.initOperations(_Niveau__OclAny);
			Fragments._Niveau__OclElement.initOperations(_Niveau__OclElement);

			Fragments._Responsable__OclAny.initOperations(_Responsable__OclAny);
			Fragments._Responsable__OclElement.initOperations(_Responsable__OclElement);
			Fragments._Responsable__Responsable.initOperations(_Responsable__Responsable);

			Fragments._Ressource__OclAny.initOperations(_Ressource__OclAny);
			Fragments._Ressource__OclElement.initOperations(_Ressource__OclElement);
			Fragments._Ressource__Ressource.initOperations(_Ressource__Ressource);

			Fragments._SalleCours__OclAny.initOperations(_SalleCours__OclAny);
			Fragments._SalleCours__OclElement.initOperations(_SalleCours__OclElement);
			Fragments._SalleCours__SalleCours.initOperations(_SalleCours__SalleCours);

			Fragments._Semainier__OclAny.initOperations(_Semainier__OclAny);
			Fragments._Semainier__OclElement.initOperations(_Semainier__OclElement);
			Fragments._Semainier__Semainier.initOperations(_Semainier__Semainier);

			Fragments._Semestre__OclAny.initOperations(_Semestre__OclAny);
			Fragments._Semestre__OclElement.initOperations(_Semestre__OclElement);
			Fragments._Semestre__Semestre.initOperations(_Semestre__Semestre);

			Fragments._Specialite__OclAny.initOperations(_Specialite__OclAny);
			Fragments._Specialite__OclElement.initOperations(_Specialite__OclElement);
			Fragments._Specialite__Specialite.initOperations(_Specialite__Specialite);

			Fragments._TypeRess__OclAny.initOperations(_TypeRess__OclAny);
			Fragments._TypeRess__OclElement.initOperations(_TypeRess__OclElement);
			Fragments._TypeRess__OclEnumeration.initOperations(_TypeRess__OclEnumeration);
			Fragments._TypeRess__OclType.initOperations(_TypeRess__OclType);
			Fragments._TypeRess__TypeRess.initOperations(_TypeRess__TypeRess);

			Fragments._TypeSE__OclAny.initOperations(_TypeSE__OclAny);
			Fragments._TypeSE__OclElement.initOperations(_TypeSE__OclElement);
			Fragments._TypeSE__OclEnumeration.initOperations(_TypeSE__OclEnumeration);
			Fragments._TypeSE__OclType.initOperations(_TypeSE__OclType);
			Fragments._TypeSE__TypeSE.initOperations(_TypeSE__TypeSE);

			Fragments._TypeUE__OclAny.initOperations(_TypeUE__OclAny);
			Fragments._TypeUE__OclElement.initOperations(_TypeUE__OclElement);
			Fragments._TypeUE__OclEnumeration.initOperations(_TypeUE__OclEnumeration);
			Fragments._TypeUE__OclType.initOperations(_TypeUE__OclType);
			Fragments._TypeUE__TypeUE.initOperations(_TypeUE__TypeUE);

			Fragments._UE__OclAny.initOperations(_UE__OclAny);
			Fragments._UE__OclElement.initOperations(_UE__OclElement);
			Fragments._UE__UE.initOperations(_UE__UE);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _Departement = {
			Site_PedaTables.Properties._Departement__a_responsable,
			Site_PedaTables.Properties._Departement__email,
			Site_PedaTables.Properties._Departement__formation,
			Site_PedaTables.Properties._Departement__nom,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Departement__siteWeb,
			Site_PedaTables.Properties._Departement__telephone
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Formation = {
			Site_PedaTables.Properties._Formation__description,
			Site_PedaTables.Properties._Formation__niveau,
			Site_PedaTables.Properties._Formation__nom,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Jour = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Niveau = {
			Site_PedaTables.Properties._Niveau__code,
			Site_PedaTables.Properties._Niveau__description,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Niveau__responsable,
			Site_PedaTables.Properties._Niveau__semestre,
			Site_PedaTables.Properties._Niveau__specialite
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Responsable = {
			Site_PedaTables.Properties._Responsable__adresse,
			Site_PedaTables.Properties._Responsable__departement,
			Site_PedaTables.Properties._Responsable__identifiant,
			Site_PedaTables.Properties._Responsable__nom,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Responsable__telephone
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Ressource = {
			Site_PedaTables.Properties._Ressource__nom,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Ressource__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _SalleCours = {
			Site_PedaTables.Properties._SalleCours__code,
			Site_PedaTables.Properties._SalleCours__estOccupe,
			Site_PedaTables.Properties._SalleCours__nbrePlace,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Semainier = {
			Site_PedaTables.Properties._Semainier__heureDebut,
			Site_PedaTables.Properties._Semainier__heureFin,
			Site_PedaTables.Properties._Semainier__jour,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Semestre = {
			Site_PedaTables.Properties._Semestre__code,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Semestre__ue
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Specialite = {
			Site_PedaTables.Properties._Specialite__description,
			Site_PedaTables.Properties._Specialite__nom,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._Specialite__semestre
		};

		private static final ExecutorProperty /*@NonNull*/ [] _TypeRess = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _TypeSE = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _TypeUE = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _UE = {
			Site_PedaTables.Properties._UE__code,
			Site_PedaTables.Properties._UE__credit,
			Site_PedaTables.Properties._UE__description,
			Site_PedaTables.Properties._UE__nbreEtudiant,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			Site_PedaTables.Properties._UE__possede_responsable,
			Site_PedaTables.Properties._UE__ressource,
			Site_PedaTables.Properties._UE__sallecours,
			Site_PedaTables.Properties._UE__semainier,
			Site_PedaTables.Properties._UE__typeUe
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Departement__Departement.initProperties(_Departement);
			Fragments._Formation__Formation.initProperties(_Formation);
			Fragments._Jour__Jour.initProperties(_Jour);
			Fragments._Niveau__Niveau.initProperties(_Niveau);
			Fragments._Responsable__Responsable.initProperties(_Responsable);
			Fragments._Ressource__Ressource.initProperties(_Ressource);
			Fragments._SalleCours__SalleCours.initProperties(_SalleCours);
			Fragments._Semainier__Semainier.initProperties(_Semainier);
			Fragments._Semestre__Semestre.initProperties(_Semestre);
			Fragments._Specialite__Specialite.initProperties(_Specialite);
			Fragments._TypeRess__TypeRess.initProperties(_TypeRess);
			Fragments._TypeSE__TypeSE.initProperties(_TypeSE);
			Fragments._TypeUE__TypeUE.initProperties(_TypeUE);
			Fragments._UE__UE.initProperties(_UE);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _Jour__Lundi = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.JOUR.getEEnumLiteral("Lundi"), Types._Jour, 0);
		public static final EcoreExecutorEnumerationLiteral _Jour__Mardi = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.JOUR.getEEnumLiteral("Mardi"), Types._Jour, 1);
		public static final EcoreExecutorEnumerationLiteral _Jour__Mercredi = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.JOUR.getEEnumLiteral("Mercredi"), Types._Jour, 2);
		public static final EcoreExecutorEnumerationLiteral _Jour__Jeudi = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.JOUR.getEEnumLiteral("Jeudi"), Types._Jour, 3);
		public static final EcoreExecutorEnumerationLiteral _Jour__Vendredi = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.JOUR.getEEnumLiteral("Vendredi"), Types._Jour, 4);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _Jour = {
			_Jour__Lundi,
			_Jour__Mardi,
			_Jour__Mercredi,
			_Jour__Jeudi,
			_Jour__Vendredi
		};

		public static final EcoreExecutorEnumerationLiteral _TypeRess__Cours = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_RESS.getEEnumLiteral("Cours"), Types._TypeRess, 0);
		public static final EcoreExecutorEnumerationLiteral _TypeRess__TD = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_RESS.getEEnumLiteral("TD"), Types._TypeRess, 1);
		public static final EcoreExecutorEnumerationLiteral _TypeRess__TP = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_RESS.getEEnumLiteral("TP"), Types._TypeRess, 2);
		public static final EcoreExecutorEnumerationLiteral _TypeRess__Projet = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_RESS.getEEnumLiteral("Projet"), Types._TypeRess, 3);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _TypeRess = {
			_TypeRess__Cours,
			_TypeRess__TD,
			_TypeRess__TP,
			_TypeRess__Projet
		};

		public static final EcoreExecutorEnumerationLiteral _TypeSE__S1 = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_SE.getEEnumLiteral("S1"), Types._TypeSE, 0);
		public static final EcoreExecutorEnumerationLiteral _TypeSE__S2 = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_SE.getEEnumLiteral("S2"), Types._TypeSE, 1);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _TypeSE = {
			_TypeSE__S1,
			_TypeSE__S2
		};

		public static final EcoreExecutorEnumerationLiteral _TypeUE__Optionnelle = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_UE.getEEnumLiteral("Optionnelle"), Types._TypeUE, 0);
		public static final EcoreExecutorEnumerationLiteral _TypeUE__Obligatoire = new EcoreExecutorEnumerationLiteral(Site_PedaPackage.Literals.TYPE_UE.getEEnumLiteral("Obligatoire"), Types._TypeUE, 1);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _TypeUE = {
			_TypeUE__Optionnelle,
			_TypeUE__Obligatoire
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._Jour.initLiterals(_Jour);
			Types._TypeRess.initLiterals(_TypeRess);
			Types._TypeSE.initLiterals(_TypeSE);
			Types._TypeUE.initLiterals(_TypeUE);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of Site_PedaTables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new Site_PedaTables();
	}

	private Site_PedaTables() {
		super(Site_PedaPackage.eNS_URI);
	}

	/*
	 * The EClasses whose instances should be cached to support allInstances().
	 */
	private static final EClass allInstancesEClasses /*@NonNull*/ [] = {
		Site_PedaPackage.Literals.DEPARTEMENT,
		Site_PedaPackage.Literals.FORMATION,
		Site_PedaPackage.Literals.NIVEAU,
		Site_PedaPackage.Literals.RESPONSABLE,
		Site_PedaPackage.Literals.SALLE_COURS,
		Site_PedaPackage.Literals.SPECIALITE,
		Site_PedaPackage.Literals.UE
	};

	@Override
	public EClass /*@NonNull*/ [] basicGetAllInstancesClasses() {
		return allInstancesEClasses;
	}
}

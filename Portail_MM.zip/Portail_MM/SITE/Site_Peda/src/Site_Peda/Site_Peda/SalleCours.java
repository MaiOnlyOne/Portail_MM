/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Salle Cours</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.SalleCours#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.SalleCours#getNbrePlace <em>Nbre Place</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.SalleCours#isEstOccupe <em>Est Occupe</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSalleCours()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueCode'"
 * @generated
 */
public interface SalleCours extends EObject {
	/**
	 * Returns the value of the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code</em>' attribute.
	 * @see #setCode(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSalleCours_Code()
	 * @model required="true"
	 * @generated
	 */
	String getCode();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.SalleCours#getCode <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code</em>' attribute.
	 * @see #getCode()
	 * @generated
	 */
	void setCode(String value);

	/**
	 * Returns the value of the '<em><b>Nbre Place</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nbre Place</em>' attribute.
	 * @see #setNbrePlace(int)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSalleCours_NbrePlace()
	 * @model required="true"
	 * @generated
	 */
	int getNbrePlace();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.SalleCours#getNbrePlace <em>Nbre Place</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nbre Place</em>' attribute.
	 * @see #getNbrePlace()
	 * @generated
	 */
	void setNbrePlace(int value);

	/**
	 * Returns the value of the '<em><b>Est Occupe</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Est Occupe</em>' attribute.
	 * @see #setEstOccupe(boolean)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSalleCours_EstOccupe()
	 * @model required="true"
	 * @generated
	 */
	boolean isEstOccupe();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.SalleCours#isEstOccupe <em>Est Occupe</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Est Occupe</em>' attribute.
	 * @see #isEstOccupe()
	 * @generated
	 */
	void setEstOccupe(boolean value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t SalleCours.allInstances()-&gt;forAll(sc1,sc2|sc1&lt;&gt;sc2 implies sc1.code &lt;&gt; sc2.code)'"
	 * @generated
	 */
	boolean UniqueCode(DiagnosticChain diagnostics, Map<Object, Object> context);

} // SalleCours

/**
 */
package Site_Peda.Site_Peda;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see Site_Peda.Site_Peda.Site_PedaFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore"
 * @generated
 */
public interface Site_PedaPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Site_Peda";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/site_Peda";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "Site_Peda";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Site_PedaPackage eINSTANCE = Site_Peda.Site_Peda.impl.Site_PedaPackageImpl.init();

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.DepartementImpl <em>Departement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.DepartementImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getDepartement()
	 * @generated
	 */
	int DEPARTEMENT = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__NOM = 0;

	/**
	 * The feature id for the '<em><b>Site Web</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__SITE_WEB = 1;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__TELEPHONE = 2;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__EMAIL = 3;

	/**
	 * The feature id for the '<em><b>Aresponsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__ARESPONSABLE = 4;

	/**
	 * The feature id for the '<em><b>Formation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT__FORMATION = 5;

	/**
	 * The number of structural features of the '<em>Departement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Unique Nom</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The number of operations of the '<em>Departement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPARTEMENT_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.SpecialiteImpl <em>Specialite</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.SpecialiteImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSpecialite()
	 * @generated
	 */
	int SPECIALITE = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE__NOM = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Semestre</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE__SEMESTRE = 2;

	/**
	 * The number of structural features of the '<em>Specialite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Nbre semestre</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Unique Nom</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = 1;

	/**
	 * The number of operations of the '<em>Specialite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPECIALITE_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.NiveauImpl <em>Niveau</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.NiveauImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getNiveau()
	 * @generated
	 */
	int NIVEAU = 2;

	/**
	 * The feature id for the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU__CODE = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Specialite</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU__SPECIALITE = 2;

	/**
	 * The feature id for the '<em><b>Responsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU__RESPONSABLE = 3;

	/**
	 * The feature id for the '<em><b>Semestre</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU__SEMESTRE = 4;

	/**
	 * The number of structural features of the '<em>Niveau</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Unique Code</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The operation id for the '<em>Nbre semestre</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP = 1;

	/**
	 * The number of operations of the '<em>Niveau</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIVEAU_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.RessourceImpl <em>Ressource</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.RessourceImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getRessource()
	 * @generated
	 */
	int RESSOURCE = 3;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE__NOM = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Ressource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Ressource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.ResponsableImpl <em>Responsable</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.ResponsableImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getResponsable()
	 * @generated
	 */
	int RESPONSABLE = 4;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE__NOM = 0;

	/**
	 * The feature id for the '<em><b>Identifiant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE__IDENTIFIANT = 1;

	/**
	 * The feature id for the '<em><b>Adresse</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE__ADRESSE = 2;

	/**
	 * The feature id for the '<em><b>Telephone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE__TELEPHONE = 3;

	/**
	 * The feature id for the '<em><b>Departement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE__DEPARTEMENT = 4;

	/**
	 * The number of structural features of the '<em>Responsable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Unique Nom</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The number of operations of the '<em>Responsable</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESPONSABLE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.UEImpl <em>UE</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.UEImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getUE()
	 * @generated
	 */
	int UE = 5;

	/**
	 * The feature id for the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__CODE = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Nbre Etudiant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__NBRE_ETUDIANT = 2;

	/**
	 * The feature id for the '<em><b>Credit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__CREDIT = 3;

	/**
	 * The feature id for the '<em><b>Ressource</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__RESSOURCE = 4;

	/**
	 * The feature id for the '<em><b>Sallecours</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__SALLECOURS = 5;

	/**
	 * The feature id for the '<em><b>Semainier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__SEMAINIER = 6;

	/**
	 * The feature id for the '<em><b>Possede responsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__POSSEDE_RESPONSABLE = 7;

	/**
	 * The feature id for the '<em><b>Type Ue</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE__TYPE_UE = 8;

	/**
	 * The number of structural features of the '<em>UE</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE_FEATURE_COUNT = 9;

	/**
	 * The operation id for the '<em>Unique Code</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The number of operations of the '<em>UE</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.SalleCoursImpl <em>Salle Cours</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.SalleCoursImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSalleCours()
	 * @generated
	 */
	int SALLE_COURS = 6;

	/**
	 * The feature id for the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS__CODE = 0;

	/**
	 * The feature id for the '<em><b>Nbre Place</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS__NBRE_PLACE = 1;

	/**
	 * The feature id for the '<em><b>Est Occupe</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS__EST_OCCUPE = 2;

	/**
	 * The number of structural features of the '<em>Salle Cours</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Unique Code</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The number of operations of the '<em>Salle Cours</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALLE_COURS_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.SemainierImpl <em>Semainier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.SemainierImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSemainier()
	 * @generated
	 */
	int SEMAINIER = 7;

	/**
	 * The feature id for the '<em><b>Jour</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMAINIER__JOUR = 0;

	/**
	 * The feature id for the '<em><b>Heure Debut</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMAINIER__HEURE_DEBUT = 1;

	/**
	 * The feature id for the '<em><b>Heure Fin</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMAINIER__HEURE_FIN = 2;

	/**
	 * The number of structural features of the '<em>Semainier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMAINIER_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Semainier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMAINIER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.SemestreImpl <em>Semestre</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.SemestreImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSemestre()
	 * @generated
	 */
	int SEMESTRE = 8;

	/**
	 * The feature id for the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMESTRE__CODE = 0;

	/**
	 * The feature id for the '<em><b>Ue</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMESTRE__UE = 1;

	/**
	 * The number of structural features of the '<em>Semestre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMESTRE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Semestre</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEMESTRE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.impl.FormationImpl <em>Formation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.impl.FormationImpl
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getFormation()
	 * @generated
	 */
	int FORMATION = 9;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION__NOM = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Niveau</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION__NIVEAU = 2;

	/**
	 * The number of structural features of the '<em>Formation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Unique Nom</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = 0;

	/**
	 * The number of operations of the '<em>Formation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORMATION_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.TypeSE <em>Type SE</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.TypeSE
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeSE()
	 * @generated
	 */
	int TYPE_SE = 10;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.TypeUE <em>Type UE</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.TypeUE
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeUE()
	 * @generated
	 */
	int TYPE_UE = 11;

	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.TypeRess <em>Type Ress</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.TypeRess
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeRess()
	 * @generated
	 */
	int TYPE_RESS = 12;


	/**
	 * The meta object id for the '{@link Site_Peda.Site_Peda.Jour <em>Jour</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Site_Peda.Site_Peda.Jour
	 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getJour()
	 * @generated
	 */
	int JOUR = 13;


	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Departement <em>Departement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Departement</em>'.
	 * @see Site_Peda.Site_Peda.Departement
	 * @generated
	 */
	EClass getDepartement();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Departement#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getNom()
	 * @see #getDepartement()
	 * @generated
	 */
	EAttribute getDepartement_Nom();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Departement#getSiteWeb <em>Site Web</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Site Web</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getSiteWeb()
	 * @see #getDepartement()
	 * @generated
	 */
	EAttribute getDepartement_SiteWeb();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Departement#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getTelephone()
	 * @see #getDepartement()
	 * @generated
	 */
	EAttribute getDepartement_Telephone();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Departement#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getEmail()
	 * @see #getDepartement()
	 * @generated
	 */
	EAttribute getDepartement_Email();

	/**
	 * Returns the meta object for the containment reference '{@link Site_Peda.Site_Peda.Departement#getA_responsable <em>Aresponsable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Aresponsable</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getA_responsable()
	 * @see #getDepartement()
	 * @generated
	 */
	EReference getDepartement_A_responsable();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Departement#getFormation <em>Formation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Formation</em>'.
	 * @see Site_Peda.Site_Peda.Departement#getFormation()
	 * @see #getDepartement()
	 * @generated
	 */
	EReference getDepartement_Formation();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Departement#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Nom</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Nom</em>' operation.
	 * @see Site_Peda.Site_Peda.Departement#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getDepartement__UniqueNom__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Specialite <em>Specialite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Specialite</em>'.
	 * @see Site_Peda.Site_Peda.Specialite
	 * @generated
	 */
	EClass getSpecialite();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Specialite#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see Site_Peda.Site_Peda.Specialite#getNom()
	 * @see #getSpecialite()
	 * @generated
	 */
	EAttribute getSpecialite_Nom();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Specialite#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see Site_Peda.Site_Peda.Specialite#getDescription()
	 * @see #getSpecialite()
	 * @generated
	 */
	EAttribute getSpecialite_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Specialite#getSemestre <em>Semestre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Semestre</em>'.
	 * @see Site_Peda.Site_Peda.Specialite#getSemestre()
	 * @see #getSpecialite()
	 * @generated
	 */
	EReference getSpecialite_Semestre();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Specialite#nbre_semestre(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Nbre semestre</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Nbre semestre</em>' operation.
	 * @see Site_Peda.Site_Peda.Specialite#nbre_semestre(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getSpecialite__Nbre_semestre__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Specialite#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Nom</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Nom</em>' operation.
	 * @see Site_Peda.Site_Peda.Specialite#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getSpecialite__UniqueNom__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Niveau <em>Niveau</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Niveau</em>'.
	 * @see Site_Peda.Site_Peda.Niveau
	 * @generated
	 */
	EClass getNiveau();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Niveau#getCode <em>Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code</em>'.
	 * @see Site_Peda.Site_Peda.Niveau#getCode()
	 * @see #getNiveau()
	 * @generated
	 */
	EAttribute getNiveau_Code();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Niveau#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see Site_Peda.Site_Peda.Niveau#getDescription()
	 * @see #getNiveau()
	 * @generated
	 */
	EAttribute getNiveau_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Niveau#getSpecialite <em>Specialite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Specialite</em>'.
	 * @see Site_Peda.Site_Peda.Niveau#getSpecialite()
	 * @see #getNiveau()
	 * @generated
	 */
	EReference getNiveau_Specialite();

	/**
	 * Returns the meta object for the containment reference '{@link Site_Peda.Site_Peda.Niveau#getResponsable <em>Responsable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Responsable</em>'.
	 * @see Site_Peda.Site_Peda.Niveau#getResponsable()
	 * @see #getNiveau()
	 * @generated
	 */
	EReference getNiveau_Responsable();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Niveau#getSemestre <em>Semestre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Semestre</em>'.
	 * @see Site_Peda.Site_Peda.Niveau#getSemestre()
	 * @see #getNiveau()
	 * @generated
	 */
	EReference getNiveau_Semestre();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Niveau#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Code</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Code</em>' operation.
	 * @see Site_Peda.Site_Peda.Niveau#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getNiveau__UniqueCode__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Niveau#nbre_semestre(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Nbre semestre</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Nbre semestre</em>' operation.
	 * @see Site_Peda.Site_Peda.Niveau#nbre_semestre(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getNiveau__Nbre_semestre__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Ressource <em>Ressource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ressource</em>'.
	 * @see Site_Peda.Site_Peda.Ressource
	 * @generated
	 */
	EClass getRessource();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Ressource#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see Site_Peda.Site_Peda.Ressource#getNom()
	 * @see #getRessource()
	 * @generated
	 */
	EAttribute getRessource_Nom();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Ressource#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see Site_Peda.Site_Peda.Ressource#getType()
	 * @see #getRessource()
	 * @generated
	 */
	EAttribute getRessource_Type();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Responsable <em>Responsable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Responsable</em>'.
	 * @see Site_Peda.Site_Peda.Responsable
	 * @generated
	 */
	EClass getResponsable();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Responsable#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see Site_Peda.Site_Peda.Responsable#getNom()
	 * @see #getResponsable()
	 * @generated
	 */
	EAttribute getResponsable_Nom();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Responsable#getIdentifiant <em>Identifiant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Identifiant</em>'.
	 * @see Site_Peda.Site_Peda.Responsable#getIdentifiant()
	 * @see #getResponsable()
	 * @generated
	 */
	EAttribute getResponsable_Identifiant();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Responsable#getAdresse <em>Adresse</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Adresse</em>'.
	 * @see Site_Peda.Site_Peda.Responsable#getAdresse()
	 * @see #getResponsable()
	 * @generated
	 */
	EAttribute getResponsable_Adresse();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Responsable#getTelephone <em>Telephone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Telephone</em>'.
	 * @see Site_Peda.Site_Peda.Responsable#getTelephone()
	 * @see #getResponsable()
	 * @generated
	 */
	EAttribute getResponsable_Telephone();

	/**
	 * Returns the meta object for the reference '{@link Site_Peda.Site_Peda.Responsable#getDepartement <em>Departement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Departement</em>'.
	 * @see Site_Peda.Site_Peda.Responsable#getDepartement()
	 * @see #getResponsable()
	 * @generated
	 */
	EReference getResponsable_Departement();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Responsable#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Nom</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Nom</em>' operation.
	 * @see Site_Peda.Site_Peda.Responsable#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getResponsable__UniqueNom__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.UE <em>UE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>UE</em>'.
	 * @see Site_Peda.Site_Peda.UE
	 * @generated
	 */
	EClass getUE();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.UE#getCode <em>Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code</em>'.
	 * @see Site_Peda.Site_Peda.UE#getCode()
	 * @see #getUE()
	 * @generated
	 */
	EAttribute getUE_Code();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.UE#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see Site_Peda.Site_Peda.UE#getDescription()
	 * @see #getUE()
	 * @generated
	 */
	EAttribute getUE_Description();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.UE#getNbreEtudiant <em>Nbre Etudiant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nbre Etudiant</em>'.
	 * @see Site_Peda.Site_Peda.UE#getNbreEtudiant()
	 * @see #getUE()
	 * @generated
	 */
	EAttribute getUE_NbreEtudiant();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.UE#getCredit <em>Credit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Credit</em>'.
	 * @see Site_Peda.Site_Peda.UE#getCredit()
	 * @see #getUE()
	 * @generated
	 */
	EAttribute getUE_Credit();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.UE#getRessource <em>Ressource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ressource</em>'.
	 * @see Site_Peda.Site_Peda.UE#getRessource()
	 * @see #getUE()
	 * @generated
	 */
	EReference getUE_Ressource();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.UE#getSallecours <em>Sallecours</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sallecours</em>'.
	 * @see Site_Peda.Site_Peda.UE#getSallecours()
	 * @see #getUE()
	 * @generated
	 */
	EReference getUE_Sallecours();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.UE#getSemainier <em>Semainier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Semainier</em>'.
	 * @see Site_Peda.Site_Peda.UE#getSemainier()
	 * @see #getUE()
	 * @generated
	 */
	EReference getUE_Semainier();

	/**
	 * Returns the meta object for the containment reference '{@link Site_Peda.Site_Peda.UE#getPossede_responsable <em>Possede responsable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Possede responsable</em>'.
	 * @see Site_Peda.Site_Peda.UE#getPossede_responsable()
	 * @see #getUE()
	 * @generated
	 */
	EReference getUE_Possede_responsable();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.UE#getTypeUe <em>Type Ue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Ue</em>'.
	 * @see Site_Peda.Site_Peda.UE#getTypeUe()
	 * @see #getUE()
	 * @generated
	 */
	EAttribute getUE_TypeUe();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.UE#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Code</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Code</em>' operation.
	 * @see Site_Peda.Site_Peda.UE#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getUE__UniqueCode__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.SalleCours <em>Salle Cours</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Salle Cours</em>'.
	 * @see Site_Peda.Site_Peda.SalleCours
	 * @generated
	 */
	EClass getSalleCours();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.SalleCours#getCode <em>Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code</em>'.
	 * @see Site_Peda.Site_Peda.SalleCours#getCode()
	 * @see #getSalleCours()
	 * @generated
	 */
	EAttribute getSalleCours_Code();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.SalleCours#getNbrePlace <em>Nbre Place</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nbre Place</em>'.
	 * @see Site_Peda.Site_Peda.SalleCours#getNbrePlace()
	 * @see #getSalleCours()
	 * @generated
	 */
	EAttribute getSalleCours_NbrePlace();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.SalleCours#isEstOccupe <em>Est Occupe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Est Occupe</em>'.
	 * @see Site_Peda.Site_Peda.SalleCours#isEstOccupe()
	 * @see #getSalleCours()
	 * @generated
	 */
	EAttribute getSalleCours_EstOccupe();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.SalleCours#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Code</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Code</em>' operation.
	 * @see Site_Peda.Site_Peda.SalleCours#UniqueCode(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getSalleCours__UniqueCode__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Semainier <em>Semainier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Semainier</em>'.
	 * @see Site_Peda.Site_Peda.Semainier
	 * @generated
	 */
	EClass getSemainier();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Semainier#getJour <em>Jour</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Jour</em>'.
	 * @see Site_Peda.Site_Peda.Semainier#getJour()
	 * @see #getSemainier()
	 * @generated
	 */
	EAttribute getSemainier_Jour();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Semainier#getHeureDebut <em>Heure Debut</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Heure Debut</em>'.
	 * @see Site_Peda.Site_Peda.Semainier#getHeureDebut()
	 * @see #getSemainier()
	 * @generated
	 */
	EAttribute getSemainier_HeureDebut();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Semainier#getHeureFin <em>Heure Fin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Heure Fin</em>'.
	 * @see Site_Peda.Site_Peda.Semainier#getHeureFin()
	 * @see #getSemainier()
	 * @generated
	 */
	EAttribute getSemainier_HeureFin();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Semestre <em>Semestre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Semestre</em>'.
	 * @see Site_Peda.Site_Peda.Semestre
	 * @generated
	 */
	EClass getSemestre();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Semestre#getCode <em>Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code</em>'.
	 * @see Site_Peda.Site_Peda.Semestre#getCode()
	 * @see #getSemestre()
	 * @generated
	 */
	EAttribute getSemestre_Code();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Semestre#getUe <em>Ue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ue</em>'.
	 * @see Site_Peda.Site_Peda.Semestre#getUe()
	 * @see #getSemestre()
	 * @generated
	 */
	EReference getSemestre_Ue();

	/**
	 * Returns the meta object for class '{@link Site_Peda.Site_Peda.Formation <em>Formation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Formation</em>'.
	 * @see Site_Peda.Site_Peda.Formation
	 * @generated
	 */
	EClass getFormation();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Formation#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see Site_Peda.Site_Peda.Formation#getNom()
	 * @see #getFormation()
	 * @generated
	 */
	EAttribute getFormation_Nom();

	/**
	 * Returns the meta object for the attribute '{@link Site_Peda.Site_Peda.Formation#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see Site_Peda.Site_Peda.Formation#getDescription()
	 * @see #getFormation()
	 * @generated
	 */
	EAttribute getFormation_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link Site_Peda.Site_Peda.Formation#getNiveau <em>Niveau</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Niveau</em>'.
	 * @see Site_Peda.Site_Peda.Formation#getNiveau()
	 * @see #getFormation()
	 * @generated
	 */
	EReference getFormation_Niveau();

	/**
	 * Returns the meta object for the '{@link Site_Peda.Site_Peda.Formation#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Nom</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Nom</em>' operation.
	 * @see Site_Peda.Site_Peda.Formation#UniqueNom(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getFormation__UniqueNom__DiagnosticChain_Map();

	/**
	 * Returns the meta object for enum '{@link Site_Peda.Site_Peda.TypeSE <em>Type SE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type SE</em>'.
	 * @see Site_Peda.Site_Peda.TypeSE
	 * @generated
	 */
	EEnum getTypeSE();

	/**
	 * Returns the meta object for enum '{@link Site_Peda.Site_Peda.TypeUE <em>Type UE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type UE</em>'.
	 * @see Site_Peda.Site_Peda.TypeUE
	 * @generated
	 */
	EEnum getTypeUE();

	/**
	 * Returns the meta object for enum '{@link Site_Peda.Site_Peda.TypeRess <em>Type Ress</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type Ress</em>'.
	 * @see Site_Peda.Site_Peda.TypeRess
	 * @generated
	 */
	EEnum getTypeRess();

	/**
	 * Returns the meta object for enum '{@link Site_Peda.Site_Peda.Jour <em>Jour</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Jour</em>'.
	 * @see Site_Peda.Site_Peda.Jour
	 * @generated
	 */
	EEnum getJour();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Site_PedaFactory getSite_PedaFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.DepartementImpl <em>Departement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.DepartementImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getDepartement()
		 * @generated
		 */
		EClass DEPARTEMENT = eINSTANCE.getDepartement();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTEMENT__NOM = eINSTANCE.getDepartement_Nom();

		/**
		 * The meta object literal for the '<em><b>Site Web</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTEMENT__SITE_WEB = eINSTANCE.getDepartement_SiteWeb();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTEMENT__TELEPHONE = eINSTANCE.getDepartement_Telephone();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPARTEMENT__EMAIL = eINSTANCE.getDepartement_Email();

		/**
		 * The meta object literal for the '<em><b>Aresponsable</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTEMENT__ARESPONSABLE = eINSTANCE.getDepartement_A_responsable();

		/**
		 * The meta object literal for the '<em><b>Formation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEPARTEMENT__FORMATION = eINSTANCE.getDepartement_Formation();

		/**
		 * The meta object literal for the '<em><b>Unique Nom</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DEPARTEMENT___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = eINSTANCE.getDepartement__UniqueNom__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.SpecialiteImpl <em>Specialite</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.SpecialiteImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSpecialite()
		 * @generated
		 */
		EClass SPECIALITE = eINSTANCE.getSpecialite();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SPECIALITE__NOM = eINSTANCE.getSpecialite_Nom();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SPECIALITE__DESCRIPTION = eINSTANCE.getSpecialite_Description();

		/**
		 * The meta object literal for the '<em><b>Semestre</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SPECIALITE__SEMESTRE = eINSTANCE.getSpecialite_Semestre();

		/**
		 * The meta object literal for the '<em><b>Nbre semestre</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SPECIALITE___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getSpecialite__Nbre_semestre__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Unique Nom</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SPECIALITE___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = eINSTANCE.getSpecialite__UniqueNom__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.NiveauImpl <em>Niveau</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.NiveauImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getNiveau()
		 * @generated
		 */
		EClass NIVEAU = eINSTANCE.getNiveau();

		/**
		 * The meta object literal for the '<em><b>Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NIVEAU__CODE = eINSTANCE.getNiveau_Code();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NIVEAU__DESCRIPTION = eINSTANCE.getNiveau_Description();

		/**
		 * The meta object literal for the '<em><b>Specialite</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NIVEAU__SPECIALITE = eINSTANCE.getNiveau_Specialite();

		/**
		 * The meta object literal for the '<em><b>Responsable</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NIVEAU__RESPONSABLE = eINSTANCE.getNiveau_Responsable();

		/**
		 * The meta object literal for the '<em><b>Semestre</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NIVEAU__SEMESTRE = eINSTANCE.getNiveau_Semestre();

		/**
		 * The meta object literal for the '<em><b>Unique Code</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NIVEAU___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getNiveau__UniqueCode__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Nbre semestre</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NIVEAU___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getNiveau__Nbre_semestre__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.RessourceImpl <em>Ressource</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.RessourceImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getRessource()
		 * @generated
		 */
		EClass RESSOURCE = eINSTANCE.getRessource();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESSOURCE__NOM = eINSTANCE.getRessource_Nom();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESSOURCE__TYPE = eINSTANCE.getRessource_Type();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.ResponsableImpl <em>Responsable</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.ResponsableImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getResponsable()
		 * @generated
		 */
		EClass RESPONSABLE = eINSTANCE.getResponsable();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESPONSABLE__NOM = eINSTANCE.getResponsable_Nom();

		/**
		 * The meta object literal for the '<em><b>Identifiant</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESPONSABLE__IDENTIFIANT = eINSTANCE.getResponsable_Identifiant();

		/**
		 * The meta object literal for the '<em><b>Adresse</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESPONSABLE__ADRESSE = eINSTANCE.getResponsable_Adresse();

		/**
		 * The meta object literal for the '<em><b>Telephone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESPONSABLE__TELEPHONE = eINSTANCE.getResponsable_Telephone();

		/**
		 * The meta object literal for the '<em><b>Departement</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESPONSABLE__DEPARTEMENT = eINSTANCE.getResponsable_Departement();

		/**
		 * The meta object literal for the '<em><b>Unique Nom</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RESPONSABLE___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = eINSTANCE.getResponsable__UniqueNom__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.UEImpl <em>UE</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.UEImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getUE()
		 * @generated
		 */
		EClass UE = eINSTANCE.getUE();

		/**
		 * The meta object literal for the '<em><b>Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UE__CODE = eINSTANCE.getUE_Code();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UE__DESCRIPTION = eINSTANCE.getUE_Description();

		/**
		 * The meta object literal for the '<em><b>Nbre Etudiant</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UE__NBRE_ETUDIANT = eINSTANCE.getUE_NbreEtudiant();

		/**
		 * The meta object literal for the '<em><b>Credit</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UE__CREDIT = eINSTANCE.getUE_Credit();

		/**
		 * The meta object literal for the '<em><b>Ressource</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UE__RESSOURCE = eINSTANCE.getUE_Ressource();

		/**
		 * The meta object literal for the '<em><b>Sallecours</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UE__SALLECOURS = eINSTANCE.getUE_Sallecours();

		/**
		 * The meta object literal for the '<em><b>Semainier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UE__SEMAINIER = eINSTANCE.getUE_Semainier();

		/**
		 * The meta object literal for the '<em><b>Possede responsable</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UE__POSSEDE_RESPONSABLE = eINSTANCE.getUE_Possede_responsable();

		/**
		 * The meta object literal for the '<em><b>Type Ue</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UE__TYPE_UE = eINSTANCE.getUE_TypeUe();

		/**
		 * The meta object literal for the '<em><b>Unique Code</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation UE___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getUE__UniqueCode__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.SalleCoursImpl <em>Salle Cours</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.SalleCoursImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSalleCours()
		 * @generated
		 */
		EClass SALLE_COURS = eINSTANCE.getSalleCours();

		/**
		 * The meta object literal for the '<em><b>Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALLE_COURS__CODE = eINSTANCE.getSalleCours_Code();

		/**
		 * The meta object literal for the '<em><b>Nbre Place</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALLE_COURS__NBRE_PLACE = eINSTANCE.getSalleCours_NbrePlace();

		/**
		 * The meta object literal for the '<em><b>Est Occupe</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALLE_COURS__EST_OCCUPE = eINSTANCE.getSalleCours_EstOccupe();

		/**
		 * The meta object literal for the '<em><b>Unique Code</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation SALLE_COURS___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getSalleCours__UniqueCode__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.SemainierImpl <em>Semainier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.SemainierImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSemainier()
		 * @generated
		 */
		EClass SEMAINIER = eINSTANCE.getSemainier();

		/**
		 * The meta object literal for the '<em><b>Jour</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEMAINIER__JOUR = eINSTANCE.getSemainier_Jour();

		/**
		 * The meta object literal for the '<em><b>Heure Debut</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEMAINIER__HEURE_DEBUT = eINSTANCE.getSemainier_HeureDebut();

		/**
		 * The meta object literal for the '<em><b>Heure Fin</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEMAINIER__HEURE_FIN = eINSTANCE.getSemainier_HeureFin();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.SemestreImpl <em>Semestre</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.SemestreImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getSemestre()
		 * @generated
		 */
		EClass SEMESTRE = eINSTANCE.getSemestre();

		/**
		 * The meta object literal for the '<em><b>Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEMESTRE__CODE = eINSTANCE.getSemestre_Code();

		/**
		 * The meta object literal for the '<em><b>Ue</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SEMESTRE__UE = eINSTANCE.getSemestre_Ue();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.impl.FormationImpl <em>Formation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.impl.FormationImpl
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getFormation()
		 * @generated
		 */
		EClass FORMATION = eINSTANCE.getFormation();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FORMATION__NOM = eINSTANCE.getFormation_Nom();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FORMATION__DESCRIPTION = eINSTANCE.getFormation_Description();

		/**
		 * The meta object literal for the '<em><b>Niveau</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FORMATION__NIVEAU = eINSTANCE.getFormation_Niveau();

		/**
		 * The meta object literal for the '<em><b>Unique Nom</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FORMATION___UNIQUE_NOM__DIAGNOSTICCHAIN_MAP = eINSTANCE.getFormation__UniqueNom__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.TypeSE <em>Type SE</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.TypeSE
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeSE()
		 * @generated
		 */
		EEnum TYPE_SE = eINSTANCE.getTypeSE();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.TypeUE <em>Type UE</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.TypeUE
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeUE()
		 * @generated
		 */
		EEnum TYPE_UE = eINSTANCE.getTypeUE();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.TypeRess <em>Type Ress</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.TypeRess
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getTypeRess()
		 * @generated
		 */
		EEnum TYPE_RESS = eINSTANCE.getTypeRess();

		/**
		 * The meta object literal for the '{@link Site_Peda.Site_Peda.Jour <em>Jour</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see Site_Peda.Site_Peda.Jour
		 * @see Site_Peda.Site_Peda.impl.Site_PedaPackageImpl#getJour()
		 * @generated
		 */
		EEnum JOUR = eINSTANCE.getJour();

	}

} //Site_PedaPackage

/**
 */
package Site_Peda.Site_Peda.impl;

import Site_Peda.Site_Peda.Responsable;
import Site_Peda.Site_Peda.Ressource;
import Site_Peda.Site_Peda.SalleCours;
import Site_Peda.Site_Peda.Semainier;
import Site_Peda.Site_Peda.Site_PedaPackage;
import Site_Peda.Site_Peda.Site_PedaTables;
import Site_Peda.Site_Peda.TypeUE;
import Site_Peda.Site_Peda.UE;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import java.util.Map;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.ocl.pivot.StandardLibrary;
import org.eclipse.ocl.pivot.evaluation.Executor;
import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorMultipleIterationManager;
import org.eclipse.ocl.pivot.library.AbstractSimpleOperation;
import org.eclipse.ocl.pivot.library.LibraryIteration.LibraryIterationExtension;
import org.eclipse.ocl.pivot.library.classifier.ClassifierAllInstancesOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;
import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.InvalidValueException;
import org.eclipse.ocl.pivot.values.SetValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>UE</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getNbreEtudiant <em>Nbre Etudiant</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getCredit <em>Credit</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getRessource <em>Ressource</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getSallecours <em>Sallecours</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getSemainier <em>Semainier</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getPossede_responsable <em>Possede responsable</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.UEImpl#getTypeUe <em>Type Ue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UEImpl extends MinimalEObjectImpl.Container implements UE {
	/**
	 * The default value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected static final String CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected String code = CODE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getNbreEtudiant() <em>Nbre Etudiant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNbreEtudiant()
	 * @generated
	 * @ordered
	 */
	protected static final int NBRE_ETUDIANT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getNbreEtudiant() <em>Nbre Etudiant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNbreEtudiant()
	 * @generated
	 * @ordered
	 */
	protected int nbreEtudiant = NBRE_ETUDIANT_EDEFAULT;

	/**
	 * The default value of the '{@link #getCredit() <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCredit()
	 * @generated
	 * @ordered
	 */
	protected static final int CREDIT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCredit() <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCredit()
	 * @generated
	 * @ordered
	 */
	protected int credit = CREDIT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRessource() <em>Ressource</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRessource()
	 * @generated
	 * @ordered
	 */
	protected EList<Ressource> ressource;

	/**
	 * The cached value of the '{@link #getSallecours() <em>Sallecours</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSallecours()
	 * @generated
	 * @ordered
	 */
	protected EList<SalleCours> sallecours;

	/**
	 * The cached value of the '{@link #getSemainier() <em>Semainier</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSemainier()
	 * @generated
	 * @ordered
	 */
	protected EList<Semainier> semainier;

	/**
	 * The cached value of the '{@link #getPossede_responsable() <em>Possede responsable</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPossede_responsable()
	 * @generated
	 * @ordered
	 */
	protected Responsable possede_responsable;

	/**
	 * The default value of the '{@link #getTypeUe() <em>Type Ue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeUe()
	 * @generated
	 * @ordered
	 */
	protected static final TypeUE TYPE_UE_EDEFAULT = TypeUE.OPTIONNELLE;

	/**
	 * The cached value of the '{@link #getTypeUe() <em>Type Ue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeUe()
	 * @generated
	 * @ordered
	 */
	protected TypeUE typeUe = TYPE_UE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UEImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Site_PedaPackage.Literals.UE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCode() {
		return code;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCode(String newCode) {
		String oldCode = code;
		code = newCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__CODE, oldCode, code));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getNbreEtudiant() {
		return nbreEtudiant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNbreEtudiant(int newNbreEtudiant) {
		int oldNbreEtudiant = nbreEtudiant;
		nbreEtudiant = newNbreEtudiant;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__NBRE_ETUDIANT, oldNbreEtudiant, nbreEtudiant));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCredit() {
		return credit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCredit(int newCredit) {
		int oldCredit = credit;
		credit = newCredit;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__CREDIT, oldCredit, credit));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Ressource> getRessource() {
		if (ressource == null) {
			ressource = new EObjectContainmentEList<Ressource>(Ressource.class, this, Site_PedaPackage.UE__RESSOURCE);
		}
		return ressource;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SalleCours> getSallecours() {
		if (sallecours == null) {
			sallecours = new EObjectContainmentEList<SalleCours>(SalleCours.class, this, Site_PedaPackage.UE__SALLECOURS);
		}
		return sallecours;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Semainier> getSemainier() {
		if (semainier == null) {
			semainier = new EObjectContainmentEList<Semainier>(Semainier.class, this, Site_PedaPackage.UE__SEMAINIER);
		}
		return semainier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Responsable getPossede_responsable() {
		return possede_responsable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPossede_responsable(Responsable newPossede_responsable, NotificationChain msgs) {
		Responsable oldPossede_responsable = possede_responsable;
		possede_responsable = newPossede_responsable;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__POSSEDE_RESPONSABLE, oldPossede_responsable, newPossede_responsable);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPossede_responsable(Responsable newPossede_responsable) {
		if (newPossede_responsable != possede_responsable) {
			NotificationChain msgs = null;
			if (possede_responsable != null)
				msgs = ((InternalEObject)possede_responsable).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Site_PedaPackage.UE__POSSEDE_RESPONSABLE, null, msgs);
			if (newPossede_responsable != null)
				msgs = ((InternalEObject)newPossede_responsable).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Site_PedaPackage.UE__POSSEDE_RESPONSABLE, null, msgs);
			msgs = basicSetPossede_responsable(newPossede_responsable, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__POSSEDE_RESPONSABLE, newPossede_responsable, newPossede_responsable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TypeUE getTypeUe() {
		return typeUe;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTypeUe(TypeUE newTypeUe) {
		TypeUE oldTypeUe = typeUe;
		typeUe = newTypeUe == null ? TYPE_UE_EDEFAULT : newTypeUe;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.UE__TYPE_UE, oldTypeUe, typeUe));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean UniqueCode(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "UE::UniqueCode";
		try {
			/**
			 *
			 * inv UniqueCode:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[?] = UE.allInstances()
			 *         ->forAll(u1, u2 | u1 <> u2 implies u1.code <> u2.code)
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ StandardLibrary standardLibrary = idResolver.getStandardLibrary();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, Site_PedaPackage.Literals.UE___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, Site_PedaTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			}
			else {
				/*@Caught*/ Object CAUGHT_result;
				try {
					final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_Site_Peda_c_c_UE = idResolver.getClass(Site_PedaTables.CLSSid_UE, null);
					final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, Site_PedaTables.SET_CLSSid_UE, TYP_Site_Peda_c_c_UE);
					final org.eclipse.ocl.pivot.Class TYPE_result_0 = executor.getStaticTypeOfValue(null, allInstances);
					final LibraryIterationExtension IMPL_result_0 = (LibraryIterationExtension)TYPE_result_0.lookupImplementation(standardLibrary, OCLstdlibTables.Operations._Collection__1_forAll);
					final /*@NonNull*/ Object ACC_result_0 = IMPL_result_0.createAccumulatorValue(executor, TypeId.BOOLEAN, TypeId.BOOLEAN);
					/**
					 * Implementation of the iterator body.
					 */
					final AbstractSimpleOperation BODY_result_0 = new AbstractSimpleOperation() {
						/**
						 * u1 <> u2 implies u1.code <> u2.code
						 */
						@Override
						public /*@Nullable*/ Object evaluate(final Executor executor, final TypeId typeId, final /*@Nullable*/ Object /*@NonNull*/ [] sourceAndArgumentValues) {
							final /*@NonInvalid*/ SetValue allInstances = (SetValue)sourceAndArgumentValues[0];
							final /*@NonInvalid*/ Object u1 = sourceAndArgumentValues[1];
							final /*@NonInvalid*/ Object u2 = sourceAndArgumentValues[2];
							/*@Caught*/ Object CAUGHT_implies;
							try {
								final /*@NonInvalid*/ UE CAST_null = (UE)u1;
								final /*@NonInvalid*/ UE CAST_null_0 = (UE)u2;
								final /*@NonInvalid*/ boolean ne = (CAST_null != null) ? !CAST_null.equals(CAST_null_0) : (CAST_null_0 != null);
								final /*@Thrown*/ Boolean implies;
								if (!ne) {
									implies = ValueUtil.TRUE_VALUE;
								}
								else {
									/*@Caught*/ Object CAUGHT_ne_0;
									try {
										if (CAST_null == null) {
											throw new InvalidValueException("Null source for \'\'http://www.example.org/site_Peda\'::UE::code\'");
										}
										final /*@Thrown*/ String code = CAST_null.getCode();
										if (CAST_null_0 == null) {
											throw new InvalidValueException("Null source for \'\'http://www.example.org/site_Peda\'::UE::code\'");
										}
										final /*@Thrown*/ String code_0 = CAST_null_0.getCode();
										final /*@Thrown*/ boolean ne_0 = !code.equals(code_0);
										CAUGHT_ne_0 = ne_0;
									}
									catch (Exception e) {
										CAUGHT_ne_0 = ValueUtil.createInvalidValue(e);
									}
									if (CAUGHT_ne_0 == ValueUtil.TRUE_VALUE) {
										implies = ValueUtil.TRUE_VALUE;
									}
									else {
										if (CAUGHT_ne_0 instanceof InvalidValueException) {
											throw (InvalidValueException)CAUGHT_ne_0;
										}
										implies = ValueUtil.FALSE_VALUE;
									}
								}
								CAUGHT_implies = implies;
							}
							catch (Exception e) {
								CAUGHT_implies = ValueUtil.createInvalidValue(e);
							}
							return CAUGHT_implies;
						}
					};
					final ExecutorMultipleIterationManager MGR_result_0 = new ExecutorMultipleIterationManager(executor, 2, false, TypeId.BOOLEAN, BODY_result_0, allInstances, ACC_result_0);
					final /*@Thrown*/ Boolean result = (Boolean)IMPL_result_0.evaluateIteration(MGR_result_0);
					CAUGHT_result = result;
				}
				catch (Exception e) {
					CAUGHT_result = ValueUtil.createInvalidValue(e);
				}
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, CAUGHT_result, Site_PedaTables.INT_0).booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Site_PedaPackage.UE__RESSOURCE:
				return ((InternalEList<?>)getRessource()).basicRemove(otherEnd, msgs);
			case Site_PedaPackage.UE__SALLECOURS:
				return ((InternalEList<?>)getSallecours()).basicRemove(otherEnd, msgs);
			case Site_PedaPackage.UE__SEMAINIER:
				return ((InternalEList<?>)getSemainier()).basicRemove(otherEnd, msgs);
			case Site_PedaPackage.UE__POSSEDE_RESPONSABLE:
				return basicSetPossede_responsable(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Site_PedaPackage.UE__CODE:
				return getCode();
			case Site_PedaPackage.UE__DESCRIPTION:
				return getDescription();
			case Site_PedaPackage.UE__NBRE_ETUDIANT:
				return getNbreEtudiant();
			case Site_PedaPackage.UE__CREDIT:
				return getCredit();
			case Site_PedaPackage.UE__RESSOURCE:
				return getRessource();
			case Site_PedaPackage.UE__SALLECOURS:
				return getSallecours();
			case Site_PedaPackage.UE__SEMAINIER:
				return getSemainier();
			case Site_PedaPackage.UE__POSSEDE_RESPONSABLE:
				return getPossede_responsable();
			case Site_PedaPackage.UE__TYPE_UE:
				return getTypeUe();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Site_PedaPackage.UE__CODE:
				setCode((String)newValue);
				return;
			case Site_PedaPackage.UE__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case Site_PedaPackage.UE__NBRE_ETUDIANT:
				setNbreEtudiant((Integer)newValue);
				return;
			case Site_PedaPackage.UE__CREDIT:
				setCredit((Integer)newValue);
				return;
			case Site_PedaPackage.UE__RESSOURCE:
				getRessource().clear();
				getRessource().addAll((Collection<? extends Ressource>)newValue);
				return;
			case Site_PedaPackage.UE__SALLECOURS:
				getSallecours().clear();
				getSallecours().addAll((Collection<? extends SalleCours>)newValue);
				return;
			case Site_PedaPackage.UE__SEMAINIER:
				getSemainier().clear();
				getSemainier().addAll((Collection<? extends Semainier>)newValue);
				return;
			case Site_PedaPackage.UE__POSSEDE_RESPONSABLE:
				setPossede_responsable((Responsable)newValue);
				return;
			case Site_PedaPackage.UE__TYPE_UE:
				setTypeUe((TypeUE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Site_PedaPackage.UE__CODE:
				setCode(CODE_EDEFAULT);
				return;
			case Site_PedaPackage.UE__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case Site_PedaPackage.UE__NBRE_ETUDIANT:
				setNbreEtudiant(NBRE_ETUDIANT_EDEFAULT);
				return;
			case Site_PedaPackage.UE__CREDIT:
				setCredit(CREDIT_EDEFAULT);
				return;
			case Site_PedaPackage.UE__RESSOURCE:
				getRessource().clear();
				return;
			case Site_PedaPackage.UE__SALLECOURS:
				getSallecours().clear();
				return;
			case Site_PedaPackage.UE__SEMAINIER:
				getSemainier().clear();
				return;
			case Site_PedaPackage.UE__POSSEDE_RESPONSABLE:
				setPossede_responsable((Responsable)null);
				return;
			case Site_PedaPackage.UE__TYPE_UE:
				setTypeUe(TYPE_UE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Site_PedaPackage.UE__CODE:
				return CODE_EDEFAULT == null ? code != null : !CODE_EDEFAULT.equals(code);
			case Site_PedaPackage.UE__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case Site_PedaPackage.UE__NBRE_ETUDIANT:
				return nbreEtudiant != NBRE_ETUDIANT_EDEFAULT;
			case Site_PedaPackage.UE__CREDIT:
				return credit != CREDIT_EDEFAULT;
			case Site_PedaPackage.UE__RESSOURCE:
				return ressource != null && !ressource.isEmpty();
			case Site_PedaPackage.UE__SALLECOURS:
				return sallecours != null && !sallecours.isEmpty();
			case Site_PedaPackage.UE__SEMAINIER:
				return semainier != null && !semainier.isEmpty();
			case Site_PedaPackage.UE__POSSEDE_RESPONSABLE:
				return possede_responsable != null;
			case Site_PedaPackage.UE__TYPE_UE:
				return typeUe != TYPE_UE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Site_PedaPackage.UE___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP:
				return UniqueCode((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (code: ");
		result.append(code);
		result.append(", description: ");
		result.append(description);
		result.append(", nbreEtudiant: ");
		result.append(nbreEtudiant);
		result.append(", credit: ");
		result.append(credit);
		result.append(", typeUe: ");
		result.append(typeUe);
		result.append(')');
		return result.toString();
	}

} //UEImpl

/**
 */
package Site_Peda.Site_Peda.impl;

import Site_Peda.Site_Peda.Niveau;
import Site_Peda.Site_Peda.Responsable;
import Site_Peda.Site_Peda.Semestre;
import Site_Peda.Site_Peda.Site_PedaPackage;
import Site_Peda.Site_Peda.Site_PedaTables;
import Site_Peda.Site_Peda.Specialite;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import java.util.List;
import java.util.Map;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.ocl.pivot.StandardLibrary;
import org.eclipse.ocl.pivot.evaluation.Executor;
import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorMultipleIterationManager;
import org.eclipse.ocl.pivot.library.AbstractSimpleOperation;
import org.eclipse.ocl.pivot.library.LibraryIteration.LibraryIterationExtension;
import org.eclipse.ocl.pivot.library.classifier.ClassifierAllInstancesOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionSizeOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;
import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.InvalidValueException;
import org.eclipse.ocl.pivot.values.OrderedSetValue;
import org.eclipse.ocl.pivot.values.SetValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Niveau</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.impl.NiveauImpl#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.NiveauImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.NiveauImpl#getSpecialite <em>Specialite</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.NiveauImpl#getResponsable <em>Responsable</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.impl.NiveauImpl#getSemestre <em>Semestre</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NiveauImpl extends MinimalEObjectImpl.Container implements Niveau {
	/**
	 * The default value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected static final String CODE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCode() <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCode()
	 * @generated
	 * @ordered
	 */
	protected String code = CODE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSpecialite() <em>Specialite</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpecialite()
	 * @generated
	 * @ordered
	 */
	protected EList<Specialite> specialite;

	/**
	 * The cached value of the '{@link #getResponsable() <em>Responsable</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResponsable()
	 * @generated
	 * @ordered
	 */
	protected Responsable responsable;

	/**
	 * The cached value of the '{@link #getSemestre() <em>Semestre</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSemestre()
	 * @generated
	 * @ordered
	 */
	protected EList<Semestre> semestre;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NiveauImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Site_PedaPackage.Literals.NIVEAU;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCode() {
		return code;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCode(String newCode) {
		String oldCode = code;
		code = newCode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.NIVEAU__CODE, oldCode, code));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.NIVEAU__DESCRIPTION, oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Specialite> getSpecialite() {
		if (specialite == null) {
			specialite = new EObjectContainmentEList<Specialite>(Specialite.class, this, Site_PedaPackage.NIVEAU__SPECIALITE);
		}
		return specialite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Responsable getResponsable() {
		return responsable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetResponsable(Responsable newResponsable, NotificationChain msgs) {
		Responsable oldResponsable = responsable;
		responsable = newResponsable;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Site_PedaPackage.NIVEAU__RESPONSABLE, oldResponsable, newResponsable);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setResponsable(Responsable newResponsable) {
		if (newResponsable != responsable) {
			NotificationChain msgs = null;
			if (responsable != null)
				msgs = ((InternalEObject)responsable).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Site_PedaPackage.NIVEAU__RESPONSABLE, null, msgs);
			if (newResponsable != null)
				msgs = ((InternalEObject)newResponsable).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Site_PedaPackage.NIVEAU__RESPONSABLE, null, msgs);
			msgs = basicSetResponsable(newResponsable, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Site_PedaPackage.NIVEAU__RESPONSABLE, newResponsable, newResponsable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Semestre> getSemestre() {
		if (semestre == null) {
			semestre = new EObjectContainmentEList<Semestre>(Semestre.class, this, Site_PedaPackage.NIVEAU__SEMESTRE);
		}
		return semestre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean UniqueCode(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Niveau::UniqueCode";
		try {
			/**
			 *
			 * inv UniqueCode:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[?] = Niveau.allInstances()
			 *         ->forAll(n1, n2 | n1 <> n2 implies n1.code <> n2.code)
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ StandardLibrary standardLibrary = idResolver.getStandardLibrary();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, Site_PedaPackage.Literals.NIVEAU___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, Site_PedaTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			}
			else {
				/*@Caught*/ Object CAUGHT_result;
				try {
					final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_Site_Peda_c_c_Niveau = idResolver.getClass(Site_PedaTables.CLSSid_Niveau, null);
					final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, Site_PedaTables.SET_CLSSid_Niveau, TYP_Site_Peda_c_c_Niveau);
					final org.eclipse.ocl.pivot.Class TYPE_result_0 = executor.getStaticTypeOfValue(null, allInstances);
					final LibraryIterationExtension IMPL_result_0 = (LibraryIterationExtension)TYPE_result_0.lookupImplementation(standardLibrary, OCLstdlibTables.Operations._Collection__1_forAll);
					final /*@NonNull*/ Object ACC_result_0 = IMPL_result_0.createAccumulatorValue(executor, TypeId.BOOLEAN, TypeId.BOOLEAN);
					/**
					 * Implementation of the iterator body.
					 */
					final AbstractSimpleOperation BODY_result_0 = new AbstractSimpleOperation() {
						/**
						 * n1 <> n2 implies n1.code <> n2.code
						 */
						@Override
						public /*@Nullable*/ Object evaluate(final Executor executor, final TypeId typeId, final /*@Nullable*/ Object /*@NonNull*/ [] sourceAndArgumentValues) {
							final /*@NonInvalid*/ SetValue allInstances = (SetValue)sourceAndArgumentValues[0];
							final /*@NonInvalid*/ Object n1 = sourceAndArgumentValues[1];
							final /*@NonInvalid*/ Object n2 = sourceAndArgumentValues[2];
							/*@Caught*/ Object CAUGHT_implies;
							try {
								final /*@NonInvalid*/ Niveau CAST_null = (Niveau)n1;
								final /*@NonInvalid*/ Niveau CAST_null_0 = (Niveau)n2;
								final /*@NonInvalid*/ boolean ne = (CAST_null != null) ? !CAST_null.equals(CAST_null_0) : (CAST_null_0 != null);
								final /*@Thrown*/ Boolean implies;
								if (!ne) {
									implies = ValueUtil.TRUE_VALUE;
								}
								else {
									/*@Caught*/ Object CAUGHT_ne_0;
									try {
										if (CAST_null == null) {
											throw new InvalidValueException("Null source for \'\'http://www.example.org/site_Peda\'::Niveau::code\'");
										}
										final /*@Thrown*/ String code = CAST_null.getCode();
										if (CAST_null_0 == null) {
											throw new InvalidValueException("Null source for \'\'http://www.example.org/site_Peda\'::Niveau::code\'");
										}
										final /*@Thrown*/ String code_0 = CAST_null_0.getCode();
										final /*@Thrown*/ boolean ne_0 = !code.equals(code_0);
										CAUGHT_ne_0 = ne_0;
									}
									catch (Exception e) {
										CAUGHT_ne_0 = ValueUtil.createInvalidValue(e);
									}
									if (CAUGHT_ne_0 == ValueUtil.TRUE_VALUE) {
										implies = ValueUtil.TRUE_VALUE;
									}
									else {
										if (CAUGHT_ne_0 instanceof InvalidValueException) {
											throw (InvalidValueException)CAUGHT_ne_0;
										}
										implies = ValueUtil.FALSE_VALUE;
									}
								}
								CAUGHT_implies = implies;
							}
							catch (Exception e) {
								CAUGHT_implies = ValueUtil.createInvalidValue(e);
							}
							return CAUGHT_implies;
						}
					};
					final ExecutorMultipleIterationManager MGR_result_0 = new ExecutorMultipleIterationManager(executor, 2, false, TypeId.BOOLEAN, BODY_result_0, allInstances, ACC_result_0);
					final /*@Thrown*/ Boolean result = (Boolean)IMPL_result_0.evaluateIteration(MGR_result_0);
					CAUGHT_result = result;
				}
				catch (Exception e) {
					CAUGHT_result = ValueUtil.createInvalidValue(e);
				}
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, CAUGHT_result, Site_PedaTables.INT_0).booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean nbre_semestre(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Niveau::nbre_semestre";
		try {
			/**
			 *
			 * inv nbre_semestre:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = semestre->size() = 2
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, Site_PedaPackage.Literals.NIVEAU___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, Site_PedaTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean IF_le;
			if (le) {
				IF_le = true;
			}
			else {
				final /*@NonInvalid*/ List<Semestre> semestre = this.getSemestre();
				final /*@NonInvalid*/ OrderedSetValue BOXED_semestre = idResolver.createOrderedSetOfAll(Site_PedaTables.ORD_CLSSid_Semestre, semestre);
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(BOXED_semestre);
				final /*@NonInvalid*/ boolean result = size.equals(Site_PedaTables.INT_2);
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, Site_PedaTables.INT_0).booleanValue();
				IF_le = logDiagnostic;
			}
			return IF_le;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Site_PedaPackage.NIVEAU__SPECIALITE:
				return ((InternalEList<?>)getSpecialite()).basicRemove(otherEnd, msgs);
			case Site_PedaPackage.NIVEAU__RESPONSABLE:
				return basicSetResponsable(null, msgs);
			case Site_PedaPackage.NIVEAU__SEMESTRE:
				return ((InternalEList<?>)getSemestre()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Site_PedaPackage.NIVEAU__CODE:
				return getCode();
			case Site_PedaPackage.NIVEAU__DESCRIPTION:
				return getDescription();
			case Site_PedaPackage.NIVEAU__SPECIALITE:
				return getSpecialite();
			case Site_PedaPackage.NIVEAU__RESPONSABLE:
				return getResponsable();
			case Site_PedaPackage.NIVEAU__SEMESTRE:
				return getSemestre();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Site_PedaPackage.NIVEAU__CODE:
				setCode((String)newValue);
				return;
			case Site_PedaPackage.NIVEAU__DESCRIPTION:
				setDescription((String)newValue);
				return;
			case Site_PedaPackage.NIVEAU__SPECIALITE:
				getSpecialite().clear();
				getSpecialite().addAll((Collection<? extends Specialite>)newValue);
				return;
			case Site_PedaPackage.NIVEAU__RESPONSABLE:
				setResponsable((Responsable)newValue);
				return;
			case Site_PedaPackage.NIVEAU__SEMESTRE:
				getSemestre().clear();
				getSemestre().addAll((Collection<? extends Semestre>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Site_PedaPackage.NIVEAU__CODE:
				setCode(CODE_EDEFAULT);
				return;
			case Site_PedaPackage.NIVEAU__DESCRIPTION:
				setDescription(DESCRIPTION_EDEFAULT);
				return;
			case Site_PedaPackage.NIVEAU__SPECIALITE:
				getSpecialite().clear();
				return;
			case Site_PedaPackage.NIVEAU__RESPONSABLE:
				setResponsable((Responsable)null);
				return;
			case Site_PedaPackage.NIVEAU__SEMESTRE:
				getSemestre().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Site_PedaPackage.NIVEAU__CODE:
				return CODE_EDEFAULT == null ? code != null : !CODE_EDEFAULT.equals(code);
			case Site_PedaPackage.NIVEAU__DESCRIPTION:
				return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
			case Site_PedaPackage.NIVEAU__SPECIALITE:
				return specialite != null && !specialite.isEmpty();
			case Site_PedaPackage.NIVEAU__RESPONSABLE:
				return responsable != null;
			case Site_PedaPackage.NIVEAU__SEMESTRE:
				return semestre != null && !semestre.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case Site_PedaPackage.NIVEAU___UNIQUE_CODE__DIAGNOSTICCHAIN_MAP:
				return UniqueCode((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case Site_PedaPackage.NIVEAU___NBRE_SEMESTRE__DIAGNOSTICCHAIN_MAP:
				return nbre_semestre((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (code: ");
		result.append(code);
		result.append(", description: ");
		result.append(description);
		result.append(')');
		return result.toString();
	}

} //NiveauImpl

/**
 */
package Site_Peda.Site_Peda;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Semainier</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Semainier#getJour <em>Jour</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Semainier#getHeureDebut <em>Heure Debut</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Semainier#getHeureFin <em>Heure Fin</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemainier()
 * @model
 * @generated
 */
public interface Semainier extends EObject {
	/**
	 * Returns the value of the '<em><b>Jour</b></em>' attribute.
	 * The literals are from the enumeration {@link Site_Peda.Site_Peda.Jour}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Jour</em>' attribute.
	 * @see Site_Peda.Site_Peda.Jour
	 * @see #setJour(Jour)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemainier_Jour()
	 * @model
	 * @generated
	 */
	Jour getJour();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Semainier#getJour <em>Jour</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Jour</em>' attribute.
	 * @see Site_Peda.Site_Peda.Jour
	 * @see #getJour()
	 * @generated
	 */
	void setJour(Jour value);

	/**
	 * Returns the value of the '<em><b>Heure Debut</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Heure Debut</em>' attribute.
	 * @see #setHeureDebut(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemainier_HeureDebut()
	 * @model
	 * @generated
	 */
	String getHeureDebut();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Semainier#getHeureDebut <em>Heure Debut</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Heure Debut</em>' attribute.
	 * @see #getHeureDebut()
	 * @generated
	 */
	void setHeureDebut(String value);

	/**
	 * Returns the value of the '<em><b>Heure Fin</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Heure Fin</em>' attribute.
	 * @see #setHeureFin(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemainier_HeureFin()
	 * @model
	 * @generated
	 */
	String getHeureFin();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Semainier#getHeureFin <em>Heure Fin</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Heure Fin</em>' attribute.
	 * @see #getHeureFin()
	 * @generated
	 */
	void setHeureFin(String value);

} // Semainier

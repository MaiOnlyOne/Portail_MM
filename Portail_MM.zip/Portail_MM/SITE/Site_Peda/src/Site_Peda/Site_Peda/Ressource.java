/**
 */
package Site_Peda.Site_Peda;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ressource</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Ressource#getNom <em>Nom</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Ressource#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getRessource()
 * @model
 * @generated
 */
public interface Ressource extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getRessource_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Ressource#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link Site_Peda.Site_Peda.TypeRess}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeRess
	 * @see #setType(TypeRess)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getRessource_Type()
	 * @model
	 * @generated
	 */
	TypeRess getType();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Ressource#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeRess
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeRess value);

} // Ressource

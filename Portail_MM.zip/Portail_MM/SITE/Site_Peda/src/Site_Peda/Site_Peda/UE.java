/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UE</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.UE#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getNbreEtudiant <em>Nbre Etudiant</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getCredit <em>Credit</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getRessource <em>Ressource</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getSallecours <em>Sallecours</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getSemainier <em>Semainier</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getPossede_responsable <em>Possede responsable</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.UE#getTypeUe <em>Type Ue</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueCode'"
 * @generated
 */
public interface UE extends EObject {
	/**
	 * Returns the value of the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code</em>' attribute.
	 * @see #setCode(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Code()
	 * @model required="true"
	 * @generated
	 */
	String getCode();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getCode <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code</em>' attribute.
	 * @see #getCode()
	 * @generated
	 */
	void setCode(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Nbre Etudiant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nbre Etudiant</em>' attribute.
	 * @see #setNbreEtudiant(int)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_NbreEtudiant()
	 * @model required="true"
	 * @generated
	 */
	int getNbreEtudiant();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getNbreEtudiant <em>Nbre Etudiant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nbre Etudiant</em>' attribute.
	 * @see #getNbreEtudiant()
	 * @generated
	 */
	void setNbreEtudiant(int value);

	/**
	 * Returns the value of the '<em><b>Credit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Credit</em>' attribute.
	 * @see #setCredit(int)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Credit()
	 * @model required="true"
	 * @generated
	 */
	int getCredit();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getCredit <em>Credit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Credit</em>' attribute.
	 * @see #getCredit()
	 * @generated
	 */
	void setCredit(int value);

	/**
	 * Returns the value of the '<em><b>Ressource</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Ressource}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ressource</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Ressource()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Ressource> getRessource();

	/**
	 * Returns the value of the '<em><b>Sallecours</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.SalleCours}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sallecours</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Sallecours()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<SalleCours> getSallecours();

	/**
	 * Returns the value of the '<em><b>Semainier</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Semainier}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semainier</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Semainier()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Semainier> getSemainier();

	/**
	 * Returns the value of the '<em><b>Possede responsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Possede responsable</em>' containment reference.
	 * @see #setPossede_responsable(Responsable)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_Possede_responsable()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Responsable getPossede_responsable();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getPossede_responsable <em>Possede responsable</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Possede responsable</em>' containment reference.
	 * @see #getPossede_responsable()
	 * @generated
	 */
	void setPossede_responsable(Responsable value);

	/**
	 * Returns the value of the '<em><b>Type Ue</b></em>' attribute.
	 * The literals are from the enumeration {@link Site_Peda.Site_Peda.TypeUE}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type Ue</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeUE
	 * @see #setTypeUe(TypeUE)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getUE_TypeUe()
	 * @model
	 * @generated
	 */
	TypeUE getTypeUe();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.UE#getTypeUe <em>Type Ue</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type Ue</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeUE
	 * @see #getTypeUe()
	 * @generated
	 */
	void setTypeUe(TypeUE value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t UE.allInstances()-&gt;forAll(u1,u2|u1&lt;&gt;u2 implies u1.code &lt;&gt; u2.code)'"
	 * @generated
	 */
	boolean UniqueCode(DiagnosticChain diagnostics, Map<Object, Object> context);

} // UE

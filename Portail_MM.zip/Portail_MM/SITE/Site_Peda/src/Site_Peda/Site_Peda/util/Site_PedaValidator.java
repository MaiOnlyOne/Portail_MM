/**
 */
package Site_Peda.Site_Peda.util;

import Site_Peda.Site_Peda.*;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see Site_Peda.Site_Peda.Site_PedaPackage
 * @generated
 */
public class Site_PedaValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final Site_PedaValidator INSTANCE = new Site_PedaValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "Site_Peda.Site_Peda";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Nom' of 'Departement'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int DEPARTEMENT__UNIQUE_NOM = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Nbre semestre' of 'Specialite'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int SPECIALITE__NBRE_SEMESTRE = 2;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Nom' of 'Specialite'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int SPECIALITE__UNIQUE_NOM = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Code' of 'Niveau'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int NIVEAU__UNIQUE_CODE = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Nbre semestre' of 'Niveau'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int NIVEAU__NBRE_SEMESTRE = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Nom' of 'Responsable'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int RESPONSABLE__UNIQUE_NOM = 6;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Code' of 'UE'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int UE__UNIQUE_CODE = 7;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Code' of 'Salle Cours'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int SALLE_COURS__UNIQUE_CODE = 8;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Nom' of 'Formation'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int FORMATION__UNIQUE_NOM = 9;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 9;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Site_PedaValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return Site_PedaPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case Site_PedaPackage.DEPARTEMENT:
				return validateDepartement((Departement)value, diagnostics, context);
			case Site_PedaPackage.SPECIALITE:
				return validateSpecialite((Specialite)value, diagnostics, context);
			case Site_PedaPackage.NIVEAU:
				return validateNiveau((Niveau)value, diagnostics, context);
			case Site_PedaPackage.RESSOURCE:
				return validateRessource((Ressource)value, diagnostics, context);
			case Site_PedaPackage.RESPONSABLE:
				return validateResponsable((Responsable)value, diagnostics, context);
			case Site_PedaPackage.UE:
				return validateUE((UE)value, diagnostics, context);
			case Site_PedaPackage.SALLE_COURS:
				return validateSalleCours((SalleCours)value, diagnostics, context);
			case Site_PedaPackage.SEMAINIER:
				return validateSemainier((Semainier)value, diagnostics, context);
			case Site_PedaPackage.SEMESTRE:
				return validateSemestre((Semestre)value, diagnostics, context);
			case Site_PedaPackage.FORMATION:
				return validateFormation((Formation)value, diagnostics, context);
			case Site_PedaPackage.TYPE_SE:
				return validateTypeSE((TypeSE)value, diagnostics, context);
			case Site_PedaPackage.TYPE_UE:
				return validateTypeUE((TypeUE)value, diagnostics, context);
			case Site_PedaPackage.TYPE_RESS:
				return validateTypeRess((TypeRess)value, diagnostics, context);
			case Site_PedaPackage.JOUR:
				return validateJour((Jour)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDepartement(Departement departement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(departement, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(departement, diagnostics, context);
		if (result || diagnostics != null) result &= validateDepartement_UniqueNom(departement, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueNom constraint of '<em>Departement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDepartement_UniqueNom(Departement departement, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return departement.UniqueNom(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSpecialite(Specialite specialite, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(specialite, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validateSpecialite_UniqueNom(specialite, diagnostics, context);
		if (result || diagnostics != null) result &= validateSpecialite_nbre_semestre(specialite, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueNom constraint of '<em>Specialite</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSpecialite_UniqueNom(Specialite specialite, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return specialite.UniqueNom(diagnostics, context);
	}

	/**
	 * Validates the nbre_semestre constraint of '<em>Specialite</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSpecialite_nbre_semestre(Specialite specialite, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return specialite.nbre_semestre(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNiveau(Niveau niveau, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(niveau, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validateNiveau_nbre_semestre(niveau, diagnostics, context);
		if (result || diagnostics != null) result &= validateNiveau_UniqueCode(niveau, diagnostics, context);
		return result;
	}

	/**
	 * Validates the nbre_semestre constraint of '<em>Niveau</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNiveau_nbre_semestre(Niveau niveau, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return niveau.nbre_semestre(diagnostics, context);
	}

	/**
	 * Validates the UniqueCode constraint of '<em>Niveau</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateNiveau_UniqueCode(Niveau niveau, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return niveau.UniqueCode(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRessource(Ressource ressource, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(ressource, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateResponsable(Responsable responsable, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(responsable, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(responsable, diagnostics, context);
		if (result || diagnostics != null) result &= validateResponsable_UniqueNom(responsable, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueNom constraint of '<em>Responsable</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateResponsable_UniqueNom(Responsable responsable, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return responsable.UniqueNom(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUE(UE ue, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(ue, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(ue, diagnostics, context);
		if (result || diagnostics != null) result &= validateUE_UniqueCode(ue, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueCode constraint of '<em>UE</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUE_UniqueCode(UE ue, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return ue.UniqueCode(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSalleCours(SalleCours salleCours, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(salleCours, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(salleCours, diagnostics, context);
		if (result || diagnostics != null) result &= validateSalleCours_UniqueCode(salleCours, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueCode constraint of '<em>Salle Cours</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSalleCours_UniqueCode(SalleCours salleCours, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return salleCours.UniqueCode(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSemainier(Semainier semainier, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(semainier, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSemestre(Semestre semestre, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(semestre, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFormation(Formation formation, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(formation, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(formation, diagnostics, context);
		if (result || diagnostics != null) result &= validateFormation_UniqueNom(formation, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueNom constraint of '<em>Formation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFormation_UniqueNom(Formation formation, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return formation.UniqueNom(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTypeSE(TypeSE typeSE, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTypeUE(TypeUE typeUE, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTypeRess(TypeRess typeRess, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateJour(Jour jour, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //Site_PedaValidator

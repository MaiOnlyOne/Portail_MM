/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Specialite</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Specialite#getNom <em>Nom</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Specialite#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Specialite#getSemestre <em>Semestre</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSpecialite()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueNom'"
 * @generated
 */
public interface Specialite extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSpecialite_Nom()
	 * @model required="true"
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Specialite#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSpecialite_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Specialite#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Semestre</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Semestre}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semestre</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSpecialite_Semestre()
	 * @model containment="true" lower="2" upper="2"
	 * @generated
	 */
	EList<Semestre> getSemestre();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t   self.semestre-&gt;size()=2'"
	 * @generated
	 */
	boolean nbre_semestre(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t Specialite.allInstances()-&gt;forAll(s1,s2|s1&lt;&gt;s2 implies s1.nom &lt;&gt; s2.nom)'"
	 * @generated
	 */
	boolean UniqueNom(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Specialite

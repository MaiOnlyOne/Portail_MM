/**
 */
package Site_Peda.Site_Peda;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Jour Semaine</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getJourSemaine()
 * @model
 * @generated
 */
public enum JourSemaine implements Enumerator {
	/**
	 * The '<em><b>Lundi</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LUNDI_VALUE
	 * @generated
	 * @ordered
	 */
	LUNDI(0, "Lundi", "Lundi"),

	/**
	 * The '<em><b>Mardi</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MARDI_VALUE
	 * @generated
	 * @ordered
	 */
	MARDI(1, "Mardi", "Mardi"),

	/**
	 * The '<em><b>Mercredi</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MERCREDI_VALUE
	 * @generated
	 * @ordered
	 */
	MERCREDI(2, "Mercredi", "Mercredi"),

	/**
	 * The '<em><b>Jeudii</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JEUDII_VALUE
	 * @generated
	 * @ordered
	 */
	JEUDII(3, "Jeudii", "Jeudii"),

	/**
	 * The '<em><b>Vendredi</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VENDREDI_VALUE
	 * @generated
	 * @ordered
	 */
	VENDREDI(4, "Vendredi", "Vendredi");

	/**
	 * The '<em><b>Lundi</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LUNDI
	 * @model name="Lundi"
	 * @generated
	 * @ordered
	 */
	public static final int LUNDI_VALUE = 0;

	/**
	 * The '<em><b>Mardi</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MARDI
	 * @model name="Mardi"
	 * @generated
	 * @ordered
	 */
	public static final int MARDI_VALUE = 1;

	/**
	 * The '<em><b>Mercredi</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MERCREDI
	 * @model name="Mercredi"
	 * @generated
	 * @ordered
	 */
	public static final int MERCREDI_VALUE = 2;

	/**
	 * The '<em><b>Jeudii</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #JEUDII
	 * @model name="Jeudii"
	 * @generated
	 * @ordered
	 */
	public static final int JEUDII_VALUE = 3;

	/**
	 * The '<em><b>Vendredi</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VENDREDI
	 * @model name="Vendredi"
	 * @generated
	 * @ordered
	 */
	public static final int VENDREDI_VALUE = 4;

	/**
	 * An array of all the '<em><b>Jour Semaine</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final JourSemaine[] VALUES_ARRAY =
		new JourSemaine[] {
			LUNDI,
			MARDI,
			MERCREDI,
			JEUDII,
			VENDREDI,
		};

	/**
	 * A public read-only list of all the '<em><b>Jour Semaine</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<JourSemaine> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Jour Semaine</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static JourSemaine get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			JourSemaine result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Jour Semaine</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static JourSemaine getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			JourSemaine result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Jour Semaine</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static JourSemaine get(int value) {
		switch (value) {
			case LUNDI_VALUE: return LUNDI;
			case MARDI_VALUE: return MARDI;
			case MERCREDI_VALUE: return MERCREDI;
			case JEUDII_VALUE: return JEUDII;
			case VENDREDI_VALUE: return VENDREDI;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private JourSemaine(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //JourSemaine

/**
 */
package Site_Peda.Site_Peda;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Niveau</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Niveau#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Niveau#getDescription <em>Description</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Niveau#getSpecialite <em>Specialite</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Niveau#getResponsable <em>Responsable</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Niveau#getSemestre <em>Semestre</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='nbre_semestre'"
 * @generated
 */
public interface Niveau extends EObject {
	/**
	 * Returns the value of the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code</em>' attribute.
	 * @see #setCode(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau_Code()
	 * @model required="true"
	 * @generated
	 */
	String getCode();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Niveau#getCode <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code</em>' attribute.
	 * @see #getCode()
	 * @generated
	 */
	void setCode(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Niveau#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Specialite</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Specialite}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Specialite</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau_Specialite()
	 * @model containment="true"
	 * @generated
	 */
	EList<Specialite> getSpecialite();

	/**
	 * Returns the value of the '<em><b>Responsable</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Responsable</em>' containment reference.
	 * @see #setResponsable(Responsable)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau_Responsable()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Responsable getResponsable();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Niveau#getResponsable <em>Responsable</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Responsable</em>' containment reference.
	 * @see #getResponsable()
	 * @generated
	 */
	void setResponsable(Responsable value);

	/**
	 * Returns the value of the '<em><b>Semestre</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.Semestre}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Semestre</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getNiveau_Semestre()
	 * @model containment="true" lower="2" upper="2"
	 * @generated
	 */
	EList<Semestre> getSemestre();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t Niveau.allInstances()-&gt;forAll(n1,n2|n1&lt;&gt;n2 implies n1.code &lt;&gt; n2.code)'"
	 * @generated
	 */
	boolean UniqueCode(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t   semestre-&gt;size()=2'"
	 * @generated
	 */
	boolean nbre_semestre(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Niveau

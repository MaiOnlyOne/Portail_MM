/**
 */
package Site_Peda.Site_Peda;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Semestre</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Site_Peda.Site_Peda.Semestre#getCode <em>Code</em>}</li>
 *   <li>{@link Site_Peda.Site_Peda.Semestre#getUe <em>Ue</em>}</li>
 * </ul>
 *
 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemestre()
 * @model
 * @generated
 */
public interface Semestre extends EObject {
	/**
	 * Returns the value of the '<em><b>Code</b></em>' attribute.
	 * The literals are from the enumeration {@link Site_Peda.Site_Peda.TypeSE}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeSE
	 * @see #setCode(TypeSE)
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemestre_Code()
	 * @model required="true"
	 * @generated
	 */
	TypeSE getCode();

	/**
	 * Sets the value of the '{@link Site_Peda.Site_Peda.Semestre#getCode <em>Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code</em>' attribute.
	 * @see Site_Peda.Site_Peda.TypeSE
	 * @see #getCode()
	 * @generated
	 */
	void setCode(TypeSE value);

	/**
	 * Returns the value of the '<em><b>Ue</b></em>' containment reference list.
	 * The list contents are of type {@link Site_Peda.Site_Peda.UE}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ue</em>' containment reference list.
	 * @see Site_Peda.Site_Peda.Site_PedaPackage#getSemestre_Ue()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<UE> getUe();

} // Semestre

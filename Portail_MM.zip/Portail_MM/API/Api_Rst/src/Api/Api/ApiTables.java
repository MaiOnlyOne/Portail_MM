/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /Api_Rst/model/Api.ecore
 * using:
 *   /Api_Rst/model/Api_rest.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package Api.Api;

// import Api.Api.ApiPackage;
// import Api.Api.ApiTables;
import java.lang.String;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorType;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;

/**
 * ApiTables provides the dispatch tables for the Api for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class ApiTables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(ApiPackage.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_example_org_s_Api = IdManager.getNsURIPackageId("http://www.example.org/Api", null, ApiPackage.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_Body = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("Body", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Controller = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("Controller", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_EndPoint = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("EndPoint", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Parameter = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("Parameter", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Response = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("Response", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_SpringBootApi = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getClassId("SpringBootApi", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = ApiTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_HttpMethod = ApiTables.PACKid_http_c_s_s_www_example_org_s_Api.getEnumerationId("HttpMethod");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_200 = ValueUtil.integerValueOf("200");
	public static final /*@NonInvalid*/ CollectionTypeId SET_PRIMid_String = TypeId.SET.getSpecializedId(TypeId.STRING, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ String STR_void = "void";
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Response = TypeId.BAG.getSpecializedId(ApiTables.CLSSid_Response, false, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Controller = TypeId.ORDERED_SET.getSpecializedId(ApiTables.CLSSid_Controller, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_EndPoint = TypeId.ORDERED_SET.getSpecializedId(ApiTables.CLSSid_EndPoint, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Parameter = TypeId.ORDERED_SET.getSpecializedId(ApiTables.CLSSid_Parameter, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Response = TypeId.ORDERED_SET.getSpecializedId(ApiTables.CLSSid_Response, true, ValueUtil.ONE_VALUE, ValueUtil.UNLIMITED_VALUE);
	public static final /*@NonInvalid*/ CollectionTypeId SET_ENUMid_HttpMethod = TypeId.SET.getSpecializedId(ApiTables.ENUMid_HttpMethod, true, ValueUtil.ZERO_VALUE, ValueUtil.UNLIMITED_VALUE);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			ApiTables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _Body = new EcoreExecutorType(ApiPackage.Literals.BODY, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Controller = new EcoreExecutorType(ApiPackage.Literals.CONTROLLER, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _EndPoint = new EcoreExecutorType(ApiPackage.Literals.END_POINT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorEnumeration _HttpMethod = new EcoreExecutorEnumeration(ApiPackage.Literals.HTTP_METHOD, PACKAGE, 0);
		public static final EcoreExecutorType _Parameter = new EcoreExecutorType(ApiPackage.Literals.PARAMETER, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Response = new EcoreExecutorType(ApiPackage.Literals.RESPONSE, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _SpringBootApi = new EcoreExecutorType(ApiPackage.Literals.SPRING_BOOT_API, PACKAGE, 0 | ExecutorType.ABSTRACT);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_Body,
			_Controller,
			_EndPoint,
			_HttpMethod,
			_Parameter,
			_Response,
			_SpringBootApi
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _Body__Body = new ExecutorFragment(Types._Body, ApiTables.Types._Body);
		private static final ExecutorFragment _Body__OclAny = new ExecutorFragment(Types._Body, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Body__OclElement = new ExecutorFragment(Types._Body, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Controller__Controller = new ExecutorFragment(Types._Controller, ApiTables.Types._Controller);
		private static final ExecutorFragment _Controller__OclAny = new ExecutorFragment(Types._Controller, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Controller__OclElement = new ExecutorFragment(Types._Controller, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _EndPoint__EndPoint = new ExecutorFragment(Types._EndPoint, ApiTables.Types._EndPoint);
		private static final ExecutorFragment _EndPoint__OclAny = new ExecutorFragment(Types._EndPoint, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _EndPoint__OclElement = new ExecutorFragment(Types._EndPoint, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _HttpMethod__HttpMethod = new ExecutorFragment(Types._HttpMethod, ApiTables.Types._HttpMethod);
		private static final ExecutorFragment _HttpMethod__OclAny = new ExecutorFragment(Types._HttpMethod, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _HttpMethod__OclElement = new ExecutorFragment(Types._HttpMethod, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _HttpMethod__OclEnumeration = new ExecutorFragment(Types._HttpMethod, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _HttpMethod__OclType = new ExecutorFragment(Types._HttpMethod, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Parameter__OclAny = new ExecutorFragment(Types._Parameter, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Parameter__OclElement = new ExecutorFragment(Types._Parameter, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Parameter__Parameter = new ExecutorFragment(Types._Parameter, ApiTables.Types._Parameter);

		private static final ExecutorFragment _Response__OclAny = new ExecutorFragment(Types._Response, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Response__OclElement = new ExecutorFragment(Types._Response, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Response__Response = new ExecutorFragment(Types._Response, ApiTables.Types._Response);

		private static final ExecutorFragment _SpringBootApi__OclAny = new ExecutorFragment(Types._SpringBootApi, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _SpringBootApi__OclElement = new ExecutorFragment(Types._SpringBootApi, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _SpringBootApi__SpringBootApi = new ExecutorFragment(Types._SpringBootApi, ApiTables.Types._SpringBootApi);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _Body__type = new EcoreExecutorProperty(ApiPackage.Literals.BODY__TYPE, Types._Body, 0);
		public static final ExecutorProperty _Body__value = new EcoreExecutorProperty(ApiPackage.Literals.BODY__VALUE, Types._Body, 1);
		public static final ExecutorProperty _Body__Response__body = new ExecutorPropertyWithImplementation("Response", Types._Body, 2, new EcoreLibraryOppositeProperty(ApiPackage.Literals.RESPONSE__BODY));

		public static final ExecutorProperty _Controller__endpoint = new EcoreExecutorProperty(ApiPackage.Literals.CONTROLLER__ENDPOINT, Types._Controller, 0);
		public static final ExecutorProperty _Controller__name = new EcoreExecutorProperty(ApiPackage.Literals.CONTROLLER__NAME, Types._Controller, 1);
		public static final ExecutorProperty _Controller__SpringBootApi__controller = new ExecutorPropertyWithImplementation("SpringBootApi", Types._Controller, 2, new EcoreLibraryOppositeProperty(ApiPackage.Literals.SPRING_BOOT_API__CONTROLLER));

		public static final ExecutorProperty _EndPoint__httpMethod = new EcoreExecutorProperty(ApiPackage.Literals.END_POINT__HTTP_METHOD, Types._EndPoint, 0);
		public static final ExecutorProperty _EndPoint__parameter = new EcoreExecutorProperty(ApiPackage.Literals.END_POINT__PARAMETER, Types._EndPoint, 1);
		public static final ExecutorProperty _EndPoint__response = new EcoreExecutorProperty(ApiPackage.Literals.END_POINT__RESPONSE, Types._EndPoint, 2);
		public static final ExecutorProperty _EndPoint__url = new EcoreExecutorProperty(ApiPackage.Literals.END_POINT__URL, Types._EndPoint, 3);
		public static final ExecutorProperty _EndPoint__Controller__endpoint = new ExecutorPropertyWithImplementation("Controller", Types._EndPoint, 4, new EcoreLibraryOppositeProperty(ApiPackage.Literals.CONTROLLER__ENDPOINT));

		public static final ExecutorProperty _Parameter__name = new EcoreExecutorProperty(ApiPackage.Literals.PARAMETER__NAME, Types._Parameter, 0);
		public static final ExecutorProperty _Parameter__type = new EcoreExecutorProperty(ApiPackage.Literals.PARAMETER__TYPE, Types._Parameter, 1);
		public static final ExecutorProperty _Parameter__EndPoint__parameter = new ExecutorPropertyWithImplementation("EndPoint", Types._Parameter, 2, new EcoreLibraryOppositeProperty(ApiPackage.Literals.END_POINT__PARAMETER));

		public static final ExecutorProperty _Response__body = new EcoreExecutorProperty(ApiPackage.Literals.RESPONSE__BODY, Types._Response, 0);
		public static final ExecutorProperty _Response__httpStatus = new EcoreExecutorProperty(ApiPackage.Literals.RESPONSE__HTTP_STATUS, Types._Response, 1);
		public static final ExecutorProperty _Response__EndPoint__response = new ExecutorPropertyWithImplementation("EndPoint", Types._Response, 2, new EcoreLibraryOppositeProperty(ApiPackage.Literals.END_POINT__RESPONSE));

		public static final ExecutorProperty _SpringBootApi__controller = new EcoreExecutorProperty(ApiPackage.Literals.SPRING_BOOT_API__CONTROLLER, Types._SpringBootApi, 0);
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _Body =
			{
				Fragments._Body__OclAny /* 0 */,
				Fragments._Body__OclElement /* 1 */,
				Fragments._Body__Body /* 2 */
			};
		private static final int /*@NonNull*/ [] __Body = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Controller =
			{
				Fragments._Controller__OclAny /* 0 */,
				Fragments._Controller__OclElement /* 1 */,
				Fragments._Controller__Controller /* 2 */
			};
		private static final int /*@NonNull*/ [] __Controller = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _EndPoint =
			{
				Fragments._EndPoint__OclAny /* 0 */,
				Fragments._EndPoint__OclElement /* 1 */,
				Fragments._EndPoint__EndPoint /* 2 */
			};
		private static final int /*@NonNull*/ [] __EndPoint = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _HttpMethod =
			{
				Fragments._HttpMethod__OclAny /* 0 */,
				Fragments._HttpMethod__OclElement /* 1 */,
				Fragments._HttpMethod__OclType /* 2 */,
				Fragments._HttpMethod__OclEnumeration /* 3 */,
				Fragments._HttpMethod__HttpMethod /* 4 */
			};
		private static final int /*@NonNull*/ [] __HttpMethod = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Parameter =
			{
				Fragments._Parameter__OclAny /* 0 */,
				Fragments._Parameter__OclElement /* 1 */,
				Fragments._Parameter__Parameter /* 2 */
			};
		private static final int /*@NonNull*/ [] __Parameter = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Response =
			{
				Fragments._Response__OclAny /* 0 */,
				Fragments._Response__OclElement /* 1 */,
				Fragments._Response__Response /* 2 */
			};
		private static final int /*@NonNull*/ [] __Response = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _SpringBootApi =
			{
				Fragments._SpringBootApi__OclAny /* 0 */,
				Fragments._SpringBootApi__OclElement /* 1 */,
				Fragments._SpringBootApi__SpringBootApi /* 2 */
			};
		private static final int /*@NonNull*/ [] __SpringBootApi = { 1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._Body.initFragments(_Body, __Body);
			Types._Controller.initFragments(_Controller, __Controller);
			Types._EndPoint.initFragments(_EndPoint, __EndPoint);
			Types._HttpMethod.initFragments(_HttpMethod, __HttpMethod);
			Types._Parameter.initFragments(_Parameter, __Parameter);
			Types._Response.initFragments(_Response, __Response);
			Types._SpringBootApi.initFragments(_SpringBootApi, __SpringBootApi);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _Body__Body = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Body__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Body__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Controller__Controller = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Controller__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Controller__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _EndPoint__EndPoint = {};
		private static final ExecutorOperation /*@NonNull*/ [] _EndPoint__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _EndPoint__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _HttpMethod__HttpMethod = {};
		private static final ExecutorOperation /*@NonNull*/ [] _HttpMethod__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _HttpMethod__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _HttpMethod__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances(Integer[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _HttpMethod__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Parameter__Parameter = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Parameter__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Parameter__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Response__Response = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Response__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Response__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _SpringBootApi__SpringBootApi = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SpringBootApi__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _SpringBootApi__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances(Integer[1]) */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclBase /* oclBase() */,
			OCLstdlibTables.Operations._OclElement__1_oclBase /* oclBase(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclExtension /* oclExtension(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__0_oclExtensions /* oclExtensions() */,
			OCLstdlibTables.Operations._OclElement__1_oclExtensions /* oclExtensions(OclStereotype[1]) */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Body__Body.initOperations(_Body__Body);
			Fragments._Body__OclAny.initOperations(_Body__OclAny);
			Fragments._Body__OclElement.initOperations(_Body__OclElement);

			Fragments._Controller__Controller.initOperations(_Controller__Controller);
			Fragments._Controller__OclAny.initOperations(_Controller__OclAny);
			Fragments._Controller__OclElement.initOperations(_Controller__OclElement);

			Fragments._EndPoint__EndPoint.initOperations(_EndPoint__EndPoint);
			Fragments._EndPoint__OclAny.initOperations(_EndPoint__OclAny);
			Fragments._EndPoint__OclElement.initOperations(_EndPoint__OclElement);

			Fragments._HttpMethod__HttpMethod.initOperations(_HttpMethod__HttpMethod);
			Fragments._HttpMethod__OclAny.initOperations(_HttpMethod__OclAny);
			Fragments._HttpMethod__OclElement.initOperations(_HttpMethod__OclElement);
			Fragments._HttpMethod__OclEnumeration.initOperations(_HttpMethod__OclEnumeration);
			Fragments._HttpMethod__OclType.initOperations(_HttpMethod__OclType);

			Fragments._Parameter__OclAny.initOperations(_Parameter__OclAny);
			Fragments._Parameter__OclElement.initOperations(_Parameter__OclElement);
			Fragments._Parameter__Parameter.initOperations(_Parameter__Parameter);

			Fragments._Response__OclAny.initOperations(_Response__OclAny);
			Fragments._Response__OclElement.initOperations(_Response__OclElement);
			Fragments._Response__Response.initOperations(_Response__Response);

			Fragments._SpringBootApi__OclAny.initOperations(_SpringBootApi__OclAny);
			Fragments._SpringBootApi__OclElement.initOperations(_SpringBootApi__OclElement);
			Fragments._SpringBootApi__SpringBootApi.initOperations(_SpringBootApi__SpringBootApi);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _Body = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			ApiTables.Properties._Body__type,
			ApiTables.Properties._Body__value
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Controller = {
			ApiTables.Properties._Controller__endpoint,
			ApiTables.Properties._Controller__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _EndPoint = {
			ApiTables.Properties._EndPoint__httpMethod,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			ApiTables.Properties._EndPoint__parameter,
			ApiTables.Properties._EndPoint__response,
			ApiTables.Properties._EndPoint__url
		};

		private static final ExecutorProperty /*@NonNull*/ [] _HttpMethod = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Parameter = {
			ApiTables.Properties._Parameter__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			ApiTables.Properties._Parameter__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Response = {
			ApiTables.Properties._Response__body,
			ApiTables.Properties._Response__httpStatus,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _SpringBootApi = {
			ApiTables.Properties._SpringBootApi__controller,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Body__Body.initProperties(_Body);
			Fragments._Controller__Controller.initProperties(_Controller);
			Fragments._EndPoint__EndPoint.initProperties(_EndPoint);
			Fragments._HttpMethod__HttpMethod.initProperties(_HttpMethod);
			Fragments._Parameter__Parameter.initProperties(_Parameter);
			Fragments._Response__Response.initProperties(_Response);
			Fragments._SpringBootApi__SpringBootApi.initProperties(_SpringBootApi);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _HttpMethod__GET = new EcoreExecutorEnumerationLiteral(ApiPackage.Literals.HTTP_METHOD.getEEnumLiteral("GET"), Types._HttpMethod, 0);
		public static final EcoreExecutorEnumerationLiteral _HttpMethod__POST = new EcoreExecutorEnumerationLiteral(ApiPackage.Literals.HTTP_METHOD.getEEnumLiteral("POST"), Types._HttpMethod, 1);
		public static final EcoreExecutorEnumerationLiteral _HttpMethod__DELETE = new EcoreExecutorEnumerationLiteral(ApiPackage.Literals.HTTP_METHOD.getEEnumLiteral("DELETE"), Types._HttpMethod, 2);
		public static final EcoreExecutorEnumerationLiteral _HttpMethod__PUT = new EcoreExecutorEnumerationLiteral(ApiPackage.Literals.HTTP_METHOD.getEEnumLiteral("PUT"), Types._HttpMethod, 3);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _HttpMethod = {
			_HttpMethod__GET,
			_HttpMethod__POST,
			_HttpMethod__DELETE,
			_HttpMethod__PUT
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._HttpMethod.initLiterals(_HttpMethod);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of ApiTables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new ApiTables();
	}

	private ApiTables() {
		super(ApiPackage.eNS_URI);
	}
}

/**
 */
package Api.Api;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Spring Boot Api</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Api.Api.SpringBootApi#getController <em>Controller</em>}</li>
 * </ul>
 *
 * @see Api.Api.ApiPackage#getSpringBootApi()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SpringBootApi extends EObject {
	/**
	 * Returns the value of the '<em><b>Controller</b></em>' containment reference list.
	 * The list contents are of type {@link Api.Api.Controller}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controller</em>' containment reference list.
	 * @see Api.Api.ApiPackage#getSpringBootApi_Controller()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Controller> getController();

} // SpringBootApi

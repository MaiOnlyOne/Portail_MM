/**
 */
package Api.Api;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>End Point</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Api.Api.EndPoint#getUrl <em>Url</em>}</li>
 *   <li>{@link Api.Api.EndPoint#getHttpMethod <em>Http Method</em>}</li>
 *   <li>{@link Api.Api.EndPoint#getParameter <em>Parameter</em>}</li>
 *   <li>{@link Api.Api.EndPoint#getResponse <em>Response</em>}</li>
 * </ul>
 *
 * @see Api.Api.ApiPackage#getEndPoint()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='method_url_not_empty'"
 * @generated
 */
public interface EndPoint extends EObject {
	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see Api.Api.ApiPackage#getEndPoint_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link Api.Api.EndPoint#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

	/**
	 * Returns the value of the '<em><b>Http Method</b></em>' attribute.
	 * The literals are from the enumeration {@link Api.Api.HttpMethod}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Http Method</em>' attribute.
	 * @see Api.Api.HttpMethod
	 * @see #setHttpMethod(HttpMethod)
	 * @see Api.Api.ApiPackage#getEndPoint_HttpMethod()
	 * @model
	 * @generated
	 */
	HttpMethod getHttpMethod();

	/**
	 * Sets the value of the '{@link Api.Api.EndPoint#getHttpMethod <em>Http Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Http Method</em>' attribute.
	 * @see Api.Api.HttpMethod
	 * @see #getHttpMethod()
	 * @generated
	 */
	void setHttpMethod(HttpMethod value);

	/**
	 * Returns the value of the '<em><b>Parameter</b></em>' containment reference list.
	 * The list contents are of type {@link Api.Api.Parameter}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameter</em>' containment reference list.
	 * @see Api.Api.ApiPackage#getEndPoint_Parameter()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Parameter> getParameter();

	/**
	 * Returns the value of the '<em><b>Response</b></em>' containment reference list.
	 * The list contents are of type {@link Api.Api.Response}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Response</em>' containment reference list.
	 * @see Api.Api.ApiPackage#getEndPoint_Response()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Response> getResponse();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Les noms des paramètres doivent être uniques pour chaque endpoint
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='self.parameter-&gt;isUnique(name)'"
	 * @generated
	 */
	boolean UniqueName(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Les noms des paramètres doivent être uniques pour chaque endpoint
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='self.httpMethod -&gt; notEmpty() and self.url -&gt; notEmpty()'"
	 * @generated
	 */
	boolean method_url_not_empty(DiagnosticChain diagnostics, Map<Object, Object> context);

} // EndPoint

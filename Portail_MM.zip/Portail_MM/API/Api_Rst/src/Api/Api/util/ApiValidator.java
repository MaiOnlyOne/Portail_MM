/**
 */
package Api.Api.util;

import Api.Api.*;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see Api.Api.ApiPackage
 * @generated
 */
public class ApiValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final ApiValidator INSTANCE = new ApiValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "Api.Api";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Uniqu Endpoint' of 'Controller'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CONTROLLER__UNIQU_ENDPOINT = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Name' of 'Controller'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CONTROLLER__UNIQUE_NAME = 2;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Unique Name' of 'End Point'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int END_POINT__UNIQUE_NAME = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Method url not empty' of 'End Point'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int END_POINT__METHOD_URL_NOT_EMPTY = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Not Void' of 'Parameter'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int PARAMETER__NOT_VOID = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Status' of 'Response'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int RESPONSE__STATUS = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ApiValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return ApiPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case ApiPackage.SPRING_BOOT_API:
				return validateSpringBootApi((SpringBootApi)value, diagnostics, context);
			case ApiPackage.CONTROLLER:
				return validateController((Controller)value, diagnostics, context);
			case ApiPackage.END_POINT:
				return validateEndPoint((EndPoint)value, diagnostics, context);
			case ApiPackage.PARAMETER:
				return validateParameter((Parameter)value, diagnostics, context);
			case ApiPackage.RESPONSE:
				return validateResponse((Response)value, diagnostics, context);
			case ApiPackage.BODY:
				return validateBody((Body)value, diagnostics, context);
			case ApiPackage.HTTP_METHOD:
				return validateHttpMethod((HttpMethod)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSpringBootApi(SpringBootApi springBootApi, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(springBootApi, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateController(Controller controller, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(controller, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validateController_UniqueName(controller, diagnostics, context);
		if (result || diagnostics != null) result &= validateController_UniquEndpoint(controller, diagnostics, context);
		return result;
	}

	/**
	 * Validates the UniqueName constraint of '<em>Controller</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateController_UniqueName(Controller controller, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return controller.UniqueName(diagnostics, context);
	}

	/**
	 * Validates the UniquEndpoint constraint of '<em>Controller</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateController_UniquEndpoint(Controller controller, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return controller.UniquEndpoint(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEndPoint(EndPoint endPoint, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(endPoint, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validateEndPoint_method_url_not_empty(endPoint, diagnostics, context);
		if (result || diagnostics != null) result &= validateEndPoint_UniqueName(endPoint, diagnostics, context);
		return result;
	}

	/**
	 * Validates the method_url_not_empty constraint of '<em>End Point</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEndPoint_method_url_not_empty(EndPoint endPoint, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return endPoint.method_url_not_empty(diagnostics, context);
	}

	/**
	 * Validates the UniqueName constraint of '<em>End Point</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEndPoint_UniqueName(EndPoint endPoint, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return endPoint.UniqueName(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateParameter(Parameter parameter, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(parameter, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(parameter, diagnostics, context);
		if (result || diagnostics != null) result &= validateParameter_NotVoid(parameter, diagnostics, context);
		return result;
	}

	/**
	 * Validates the NotVoid constraint of '<em>Parameter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateParameter_NotVoid(Parameter parameter, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return parameter.NotVoid(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateResponse(Response response, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(response, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(response, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(response, diagnostics, context);
		if (result || diagnostics != null) result &= validateResponse_Status(response, diagnostics, context);
		return result;
	}

	/**
	 * Validates the Status constraint of '<em>Response</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateResponse_Status(Response response, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return response.Status(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBody(Body body, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(body, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHttpMethod(HttpMethod httpMethod, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //ApiValidator

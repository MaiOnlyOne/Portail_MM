/**
 */
package Api.Api;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Response</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Api.Api.Response#getHttpStatus <em>Http Status</em>}</li>
 *   <li>{@link Api.Api.Response#getBody <em>Body</em>}</li>
 * </ul>
 *
 * @see Api.Api.ApiPackage#getResponse()
 * @model interface="true" abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='Status'"
 * @generated
 */
public interface Response extends EObject {
	/**
	 * Returns the value of the '<em><b>Http Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Http Status</em>' attribute.
	 * @see #setHttpStatus(int)
	 * @see Api.Api.ApiPackage#getResponse_HttpStatus()
	 * @model required="true"
	 * @generated
	 */
	int getHttpStatus();

	/**
	 * Sets the value of the '{@link Api.Api.Response#getHttpStatus <em>Http Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Http Status</em>' attribute.
	 * @see #getHttpStatus()
	 * @generated
	 */
	void setHttpStatus(int value);

	/**
	 * Returns the value of the '<em><b>Body</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Body</em>' reference.
	 * @see #setBody(Body)
	 * @see Api.Api.ApiPackage#getResponse_Body()
	 * @model required="true"
	 * @generated
	 */
	Body getBody();

	/**
	 * Sets the value of the '{@link Api.Api.Response#getBody <em>Body</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Body</em>' reference.
	 * @see #getBody()
	 * @generated
	 */
	void setBody(Body value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Le corps d'une réponse doit être spécifié si le code de statut est 200 (OK) :
	 * <!-- end-model-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='if httpStatus = 200 then body.value -&gt; notEmpty() else true endif'"
	 * @generated
	 */
	boolean Status(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Response
